/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Time {
    public static String passed(String from, String to){
        String info = "";
        try {
            if (from.length()>11) {
                ZoneId timeZone = ZoneId.systemDefault();
                ZonedDateTime fromDate = LocalDateTime.parse(from, DateTimeFormatter.ISO_DATE_TIME).atZone(timeZone);
                ZonedDateTime toDate = LocalDateTime.parse(to, DateTimeFormatter.ISO_DATE_TIME).atZone(timeZone);
                Period period = Period.between(fromDate.toLocalDate(),toDate.toLocalDate());

                int fromDay = fromDate.getDayOfMonth() ;
                String fromMonth = getNameOfMonth(fromDate.getMonthValue());
                String froDayWeek = getDayOfWeek(fromDate.getDayOfWeek().getValue());
                int fromYear = fromDate.getYear();
                String fromTime = from.split("T")[1];

                int toDay = toDate.getDayOfMonth() ;
                String toMonth = getNameOfMonth(toDate.getMonthValue());
                String toDayWeek = getDayOfWeek(toDate.getDayOfWeek().getValue());
                int toYear = toDate.getYear();
                String toTime = to.split("T")[1];

                info = "Od " + fromDay + " " + fromMonth + " " + fromYear + " (" + froDayWeek + ") godz. " + fromTime + " do " + toDay + " " + toMonth + " " + toYear + " (" + toDayWeek + ") godz. " + toTime + " \n" +
                        " - mija: " + ChronoUnit.DAYS.between(fromDate,toDate) + " " + getTrueWordDay((int)ChronoUnit.DAYS.between(fromDate,toDate))+ ", tygodni " + ((Math.round((double) ChronoUnit.DAYS.between(fromDate,toDate)/7 * 100.0) / 100.0)) + "\n" +
                        " - godzin: " + ChronoUnit.HOURS.between(fromDate,toDate) + ", minut: " + ChronoUnit.MINUTES.between(fromDate,toDate) + " \n";
                if (!period.isZero()) {
                    int lat = period.getYears();
                    int miesiec = period.getMonths();
                    int days = period.getDays();
                    String przecinek = "";
                    info += " - kalendarzowo: ";
                    if (lat != 0) {
                        info += lat + " " + getTrueWordYear(lat);
                        przecinek = ", ";
                    }
                    if(miesiec != 0) {
                        info += przecinek + miesiec + " " + getTrueWordMonth(miesiec);
                        przecinek = ", ";
                    }
                    if (days != 0)
                        info += przecinek + days + " " + getTrueWordDay(days);
                }
            }
            else {
                LocalDate fromDate = LocalDate.parse(from, DateTimeFormatter.ISO_LOCAL_DATE);
                LocalDate toDate = LocalDate.parse(to, DateTimeFormatter.ISO_LOCAL_DATE);

                Period period = Period.between(fromDate,toDate);
                int fromDay = fromDate.getDayOfMonth() ;
                String fromMonth = getNameOfMonth(fromDate.getMonthValue());
                String froDayWeek = getDayOfWeek(fromDate.getDayOfWeek().getValue());
                int fromYear = fromDate.getYear();

                int toDay = toDate.getDayOfMonth() ;
                String toMonth = getNameOfMonth(toDate.getMonthValue());
                String toDayWeek = getDayOfWeek(toDate.getDayOfWeek().getValue());
                int toYear = toDate.getYear();

                info = "Od " + fromDay + " " + fromMonth + " " + fromYear + " (" + froDayWeek + ") do " + toDay + " " + toMonth + " " + toYear + " (" + toDayWeek + ") \n" +
                        " - mija: " + ChronoUnit.DAYS.between(fromDate,toDate) + " " + getTrueWordDay((int)ChronoUnit.DAYS.between(fromDate,toDate))+ ", tygodni " + ((Math.round((double) ChronoUnit.DAYS.between(fromDate,toDate)/7 * 100.0) / 100.0)) + "\n";
                if (!period.isZero()) {
                    int lat = period.getYears();
                    int miesiec = period.getMonths();
                    int days = period.getDays();
                    String przecinek = " ";
                    info += " - kalendarzowo:";
                    if (lat != 0) {
                        info += przecinek + lat + " " + getTrueWordYear(lat);
                        przecinek = ", ";
                    }
                    if(miesiec != 0) {
                        info += przecinek + miesiec + " " + getTrueWordMonth(miesiec);
                        przecinek = ", ";
                    }
                    if (days != 0)
                        info += przecinek + days + " " + getTrueWordDay(days);
                }
            }
        }catch (Exception e ){
            return  "*** " + e.fillInStackTrace();
        }
        return  info ;
    }

    public static String getDayOfWeek(int i){
        String [] tab = {"","poniedziałek","wtorek","sroda","czwartek","piątek","sobota","niedziela"};
        return tab[i];
    }

    public static String getNameOfMonth(int i){
        String [] tab = {"","stycznia", "lutego", "marca", "kwietnia", "maja", "czerwca",
                "lipca", "sierpnia", "września" , "października", "listopada", "grudnia"};
        return tab[i];
    }

    public static String getTrueWordYear(int i){
        if (i == 1){
            return "rok";
        }else  if (i > 1 && i <= 4){
            return "lata";
        }else
            return "lat";
    }

    public static String getTrueWordMonth(int i){
        if (i == 1){
            return "miesiąc";
        }else  if (i > 1 && i <= 4){
            return "miesiące";
        }else
            return "miesięcy";
    }

    public static String getTrueWordDay(int i){
        if (i == 1){
            return "dzień";
        }else{
            return "dni";
        }
    }
}
