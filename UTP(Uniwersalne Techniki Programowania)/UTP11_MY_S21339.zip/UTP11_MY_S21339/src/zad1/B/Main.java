package zad1.B;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
    public static void main(String[] args) {
        Buffer b = new Buffer(5);
        Producer p = new Producer(b);
        Consumer c = new Consumer(b);
        ExecutorService executor = Executors.newFixedThreadPool(2);
        executor.execute(p);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        executor.execute(c);
        try {
            Thread.sleep(15000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.exit(0);
    }
}
