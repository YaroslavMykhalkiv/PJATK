package zad1;

import javax.jms.JMSException;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Client extends JFrame {

    JMSChat jmsChat;
    JTextField txtInput;
    JTextArea txtOutput;
    JScrollPane scroll;
    String randomLetter = "" + ((char) ('a' + Math.random() * ('z'-'a' + 1)));
    String user = "User" + (int)(Math.random()*1000) + randomLetter.toUpperCase() + ": ";

    public static void main(String[] args) {
        Client client = new Client();
        client.runChat();
    }

    public Client() {
        initGui();
        setTitle(user);
        jmsChat = new JMSChat(txtOutput,user,scroll);
    }

    public void runChat() {
        while (true) {
            try {
                jmsChat.getMessage();
                Thread.sleep(50);
            } catch (InterruptedException | JMSException e) {
                e.printStackTrace();
            }
        }
    }

    private void initGui() {
        getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        txtInput = new JTextField();
        txtInput.setPreferredSize(new Dimension(300,30));
        txtInput.setFont(new Font("serif", Font.PLAIN, 17));
        txtInput.addKeyListener(new KeyListener() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (!txtInput.getText().equals("") && e.getKeyCode() == KeyEvent.VK_ENTER ) {
                    jmsChat.sendMessage(user + txtInput.getText());
                    scroll.getVerticalScrollBar().setValue(scroll.getVerticalScrollBar().getValue() + txtInput.getHeight());
                    txtInput.setText("");
                }
            }

            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        });

        txtOutput = new JTextArea(18,21);
        txtOutput.setEditable(false);
        txtOutput.setLineWrap(true);
        txtOutput.setFont(new Font("serif", Font.PLAIN, 17));


        scroll = new JScrollPane(txtOutput);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        getContentPane().add(scroll);
        getContentPane().add(txtInput);

        setPreferredSize(new Dimension(350,500));
        pack();
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
