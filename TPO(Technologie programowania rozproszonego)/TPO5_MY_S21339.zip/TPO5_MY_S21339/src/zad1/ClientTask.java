/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import java.util.List;
import java.util.concurrent.ExecutionException;

public class ClientTask implements Runnable {

    Client client;
    List<String> reqList;
    boolean showSendRes;
    String clog;

    public ClientTask(Client client, List<String> reqList, boolean showSendRes)
    {
        this.client = client;
        this.reqList = reqList;
        this.showSendRes = showSendRes;
    }
    @Override
    public void run()
    {
        client.connect();
        client.send("login " + client.id);
        for(String req : reqList)
        {
            String res = client.send(req);
            if(showSendRes) System.out.println(res);
        }
        clog = client.send("bye and log transfer");
    }

    public static ClientTask create(Client c, List<String> reqList, boolean showSendRes) {return new ClientTask(c, reqList, showSendRes); }

    public String get() throws InterruptedException, ExecutionException
    {
        while(clog == null){
            Thread.sleep(100);
        }
        return clog;
    }


}
