package zad1;

import javax.swing.*;

public class MyThread extends java.lang.Thread {
    private Object synchr = new Object();
    static int index = 1;
    int cur;
    volatile boolean status = true;
    public static JTextArea tx = new JTextArea();
    JButton button;

    public MyThread(JButton but){
        cur = index;
        index++;
        button = but;
    }

    @Override
    public void run() {
        try {
            int suma = 0;
            int random;
            while (!isInterrupted() && suma <= (cur * 1000)) {
                synchronized (synchr) {
                    if (status == false) {
                        try {
                            synchr.wait();
                        } catch (InterruptedException e) {
                        }
                    }
                }
                random = (int) (Math.random() * 100 + 1);
                suma += random;
                tx.append("Thread " + cur + "(limit = " + (cur * 1000) + "): " + random + ", suma = " + suma + "\n");
                try {
                    sleep(500);
                } catch (InterruptedException e) {
                }
            }
            end();
            try {
                sleep(2000);
            } catch (Exception e) {
            }
            Main.jp.remove(button);
            SwingUtilities.updateComponentTreeUI(Main.jf);
        }catch (Exception e ){
        }
    }

    public void setStatus(boolean option) {
        this.status = option;
        synchronized (synchr){
            synchr.notify();
        }
    }

    public void end(){
        if (!button.getText().startsWith("T")) {
            tx.append("Thread " + cur + " done!" + "\n");
            button.setText("T" + cur + " done!");
        }
        button.setEnabled(false);
    }

}
