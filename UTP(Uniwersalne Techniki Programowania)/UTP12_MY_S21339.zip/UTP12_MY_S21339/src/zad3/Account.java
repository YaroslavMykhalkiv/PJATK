package zad3;

import java.beans.*;
import java.io.Serializable;

public class Account implements Serializable {

    static int counterID = 1;
    int idAccount;
    double balance;
    private PropertyChangeSupport change = new PropertyChangeSupport(this);
    private VetoableChangeSupport limitor = new VetoableChangeSupport(this);

    public Account (double balance){
        this.balance = balance;
        idAccount = counterID++;
    }
    public Account () {
        balance = 0;
        idAccount = counterID++;
    }

    public synchronized void addLimiter(VetoableChangeListener l) {
        limitor.addVetoableChangeListener(l);
    }

    public synchronized void addChanged(PropertyChangeListener l) {
        change.addPropertyChangeListener(l);
    }

    @Override
    public String toString() {
        return "Acc " + idAccount + ": " + balance;
    }

    public synchronized void deposit(double quantity) throws PropertyVetoException {
        double oldVal = balance;
        limitor.fireVetoableChange("" + idAccount, oldVal, quantity + oldVal);
        balance += quantity;
        change.firePropertyChange("" + idAccount, oldVal, balance);
    }

    public synchronized void withdraw(double quantity) throws PropertyVetoException {
        double oldVal = balance;
        limitor.fireVetoableChange("" + idAccount, oldVal, oldVal - quantity);
        balance -= quantity;
        change.firePropertyChange("" + idAccount, oldVal, balance);
    }

    public synchronized void transfer(Account acc1, double i)throws  PropertyVetoException   {
        withdraw(i);
        acc1.deposit(i);
    }

}

