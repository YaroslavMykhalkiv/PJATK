const Joi = require('joi');

const errMessages = (errors) => {
    errors.forEach(err => {
        switch(err.code) {
            case "number.min":
                err.message = `Pole powinno byc co najmniej ${err.local.limit}`;
                break;
            case "number.max":
                err.message = `Pole powinno byc co najwyzej ${err.local.limit}`;
                break;
            case "number.base":
                err.message = "Pole jest wymagane";
                break;
            default:
                break;
        }
    });
    return errors;
}


const roomSchema = Joi.object({
    _idRoom: Joi.number()
            .optional()
            .allow(""),
    level:Joi.number()
            .min(1)
            .max(2)
            .required()
            .error(errMessages),
    number: Joi.number()
            .min(1)
            .max(99)
            .required()
            .error(errMessages),
    quantity: Joi.number()
            .min(1)
            .max(4)
            .required()
            .error(errMessages)

});

module.exports = roomSchema;

