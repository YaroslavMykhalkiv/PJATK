package zad1;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class MathAction {
    public static String add(BigDecimal one , BigDecimal two){
        String result = one.add(two).toString();
        return result;
    }

    public static String subtract(BigDecimal one , BigDecimal two){
        String result = one.subtract(two).toString();
        return result;
    }

    public static String multiply(BigDecimal one , BigDecimal two){
        String result = one.multiply(two).toString();
        return result;
    }

    public static String divide(BigDecimal one , BigDecimal two){
        String result = one.divide(two,7,RoundingMode.HALF_EVEN).toString();
        return result;
    }
}
