package zad1;

import java.awt.image.AreaAveragingScaleFilter;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class ProgLang<T,R,Q> {
    Map <String, List<String>> mapLang = new LinkedHashMap<>();
    Map <String, List<String>> mapProg = new LinkedHashMap<>();
    List<String> keys = new ArrayList<>();

    public ProgLang(String plik) {
        FileReader fr;
        String line = "";
        try {
            fr = new FileReader((String) plik);
            BufferedReader reader = new BufferedReader(fr);
            line = reader.readLine();
            String lang;
            while (line != null) {
                List<String> row = new ArrayList(Arrays.asList(line.split("\t")));
                for (int i = 0,c = 0; i < row.size(); i++, c = 0) {
                    for (int j = i + 1; j < row.size(); j++) {
                        if (row.get(i).equals(row.get(j)))
                            c++;
                        if (c > 0)
                            row.remove(j--);
                    }
                }
                lang = row.get(0);
                row.remove(0);
                for (int i = 0,c = 0; i < row.size(); i++) {
                    if(mapProg.containsKey(row.get(i)) == false){
                        mapProg.put(row.get(i),new ArrayList<>(Arrays.asList(lang)));
                    }else{
                        mapProg.get(row.get(i)).add(lang);
                    }
                }
                mapLang.put(lang,row);
                line = reader.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public Map <String, List<String>> getLangsMap(){
        return mapLang;
    }

    public Map <String, List<String>> getProgsMap(){
        return mapProg;
    }

    public Map <String, List<String>> getLangsMapSortedByNumOfProgs(){
        return sorted(mapLang);
    }

    public Map <String, List<String>> getProgsMapSortedByNumOfLangs(){
        return sorted(mapProg);
    }

    public Map <String, List<String>> getProgsMapForNumOfLangsGreaterThan(int i){
        return filtered(mapProg,i);
    }

    public Map <String, List<String>> sorted(Map <String, List<String>> maps){
        List<List<String>> list = new ArrayList((maps.values()));
        List<String> keys = new ArrayList(maps.keySet());
        Map <String, List<String>> map = new LinkedHashMap<>();
        for (int i = 0; i < list.size(); i++) {
            for (int j = 0; j < list.size() - 1; j++) {
                if (list.get(j).size() < list.get(j+1).size()){
                    Collections.swap(list,j,j+1);
                    Collections.swap(keys,j,j+1);
                } else if (list.get(j).size() == list.get(j+1).size()){
                    for (int k = 0; k < keys.get(j).length() && k < keys.get(j+1).length(); k++) {
                        if (keys.get(j).charAt(k) > keys.get(j+1).charAt(k)) {
                            Collections.swap(list, j, j + 1);
                            Collections.swap(keys, j, j + 1);
                            break;
                        }
                    }
                }
            }
        }
        for (int i = 0; i < list.size(); i++) {
            map.put(keys.get(i),list.get(i));
        }
        return map;
    }

    public Map <String, List<String>> filtered(Map <String, List<String>> maps,int number){
        List<List<String>> list = new ArrayList((maps.values()));
        List<String> keys = new ArrayList(maps.keySet());
        Map <String, List<String>> map = new LinkedHashMap<>();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).size() <= number) {
                list.remove(i);
                keys.remove(i);
                i--;
            }
        }
        for (int i = 0; i < list.size(); i++) {
            map.put(keys.get(i),list.get(i));
        }
        return map;
    }


}
