const db = require('../../config/mysql2/db');
const scheduleSchema = require('../../model/joi/Schedule');

exports.getSchedules = () => {
    return db.promise().query(`SELECT  _idSchedule,time_start,time_end,done,Pokoj.*,Pracownik.* FROM Grafik 
    LEFT JOIN Pokoj On Pokoj._idRoom = Grafik.room_id 
    LEFT JOIN Pracownik On Pracownik._idEmp = Grafik.emp_id`)
        .then((results,fields) => {
            console.log(results[0]);
            return results[0];
        })
        .catch(err =>{
            console.log(err);
            throw err;
        });

};
exports.getScheduleById = (scheduleId) =>{
    const query = `SELECT  *,room_id FROM Grafik 
    Where _idSchedule = ?`;
         return db.promise().query(query,[scheduleId])
        .then((results,fields)=>{
            const firstRow = results[0][0];
            if(!firstRow){
                return {};
            }
            if(!firstRow.done)
                firstRow.done = null;
            const schedule = {
                _idSchedule: parseInt(scheduleId),
                room_id: firstRow.room_id,
                emp_id: firstRow.emp_id,
                time_start: firstRow.time_start,
                time_end: firstRow.time_end,
                done: firstRow.done
            };
            return schedule;
        })
        .catch(err =>{
            console.log(err);
            throw err;
        });
};
exports.createSchedule= (newScheduleData) =>{
    const vRes = scheduleSchema.validate(newScheduleData, { abortEarly: false} );
    if(vRes.error) {
        return Promise.reject(vRes.error);
    }
    const room_Id = newScheduleData.room_id;
    const emp_id = newScheduleData.emp_id;
    const time_start = newScheduleData.time_start;
    const time_end = newScheduleData.time_end;
    var done = null;
    if(newScheduleData.done != "")
        done = newScheduleData.done;
   

    const sql = 'insert into Grafik (room_Id,emp_id,time_start,time_end,done) values (?,?,?,?,?)';
    return db.promise().execute(sql,[room_Id,emp_id,time_start,time_end,done]);

};
exports.updateSchedule = (scheduleId,scheduleData) =>{
    const vRes = scheduleSchema.validate(scheduleData, { abortEarly: false} );
    if(vRes.error) {
        return Promise.reject(vRes.error);
    }
    const room_id = scheduleData.room_id;
    const emp_id = scheduleData.emp_id;
    const time_start = scheduleData.time_start;
    const time_end = scheduleData.time_end;
    var done = null;
    if(scheduleData.done != "")
        done = scheduleData.done;
   

    const sql = 'Update Grafik set room_id = ?,emp_id = ?,time_start = ?,time_end = ?,done = ? where _idSchedule = ?';
    return db.promise().execute(sql,[room_id,emp_id,time_start,time_end,done,scheduleId]);
};
exports.deleteSchedule = (ScheduleId) =>{
    const sql1 = 'Delete from Grafik where _idSchedule = ?';

    return db.promise().execute(sql1,[ScheduleId]);
};