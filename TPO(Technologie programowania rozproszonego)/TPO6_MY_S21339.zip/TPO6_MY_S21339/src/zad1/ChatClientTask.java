/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

public class ChatClientTask extends FutureTask<ChatClient> {
    public ChatClientTask(Callable<ChatClient> callable) {
        super(callable);
    }


    public static ChatClientTask create(ChatClient c, List<String> messages, int waitT) {

        Callable<ChatClient> calForTask = () -> {


            c.login();
            if (waitT != 0) {
                Thread.sleep(waitT);
            }
            for (String message : messages) {
                c.send("ms" + message);
                if (waitT != 0) {
                    Thread.sleep(waitT);
                }
            }
            c.logout();
            if (waitT != 0) {
                Thread.sleep(waitT);
            }
            return c;
        };
        return new ChatClientTask(calForTask);
    }

    public ChatClient getClient()  {
        try {
            return this.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        return null;
    }
}
