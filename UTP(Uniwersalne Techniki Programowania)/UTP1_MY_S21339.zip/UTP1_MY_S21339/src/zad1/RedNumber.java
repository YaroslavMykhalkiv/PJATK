package zad1;

import java.awt.Color;
import java.awt.Component;

import javax.print.DocFlavor;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

class RedNumber extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        JLabel myRow = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, false, row, 2);
        int col = 2;
        for (int i = 0; i < 4; i++) {
            if(table.getColumnName(i).equals("Population"))
                col = i;
        }
            if ((Integer.parseInt(table.getValueAt(row, col).toString())) > 20000)
                myRow.setForeground(Color.red);
            else
                myRow.setForeground(new JLabel().getForeground());
        
        return myRow;
    }
}
