/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Server implements Runnable {

    public String host;
    public int port;



    String clientRequest;
    String log = "";
    HashMap<SelectionKey, String> mapaOfId = new HashMap<>();
    Map<SelectionKey, String> mapaInfo = new HashMap<>();

    Thread myServerThread;
    SelectionKey selectionKey;
    ServerSocketChannel serverSChannel;
    Selector selector;

    public Server(String host, int port)
    {
        this.host = host;
        this.port = port;
    }

    public void startServer() {
        myServerThread =  new Thread(this);
        myServerThread.start();
    }

    public void stopServer()
    {
        myServerThread.interrupt();
    }

    public String getServerLog()
    {
        return log;
    }

    @Override
    public void run()
    {
        try
        {
            serverSChannel = ServerSocketChannel.open();
            serverSChannel.configureBlocking(false);
            serverSChannel.socket().bind(new InetSocketAddress(host,port));
            selector = Selector.open();
            selectionKey = serverSChannel.register(selector, SelectionKey.OP_ACCEPT);
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }

        while(!Thread.currentThread().isInterrupted())
        {
            try
            {
                int count = selector.selectNow();
                if (count == 0)
                    continue;

                Iterator<SelectionKey> keys = selector.selectedKeys().iterator();

                while(keys.hasNext())
                {
                    SelectionKey key = keys.next();
                    keys.remove();

                    if(key.isAcceptable())
                    {
                        SocketChannel clientSocket = serverSChannel.accept();
                        if (clientSocket != null)
                            clientSocket
                                    .configureBlocking(false)
                                    .register(selector, SelectionKey.OP_READ);
                        continue;
                    }
                    if(key.isReadable())
                    {
                        SocketChannel channel = (SocketChannel) key.channel();
                        ByteBuffer bbuf = ByteBuffer.allocate(1024);
                        clientRequest = new String(bbuf.array(), 0 , channel.read(bbuf));

                        if(clientRequest.contains("login"))
                        {

                            mapaOfId.put(key, clientRequest.split(" ")[1]);
                            log += mapaOfId.get(key) + " logged in at " + LocalTime.now().toString().substring(0,12) + "\n";

                            mapaInfo.put(key, "=== " + mapaOfId.get(key) + " log start === " + "\nlogged in\n");
                            try
                            {
                                channel.write(ByteBuffer.wrap("logged in".getBytes()));
                            }
                            catch(IOException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else if(clientRequest.contains("-"))
                        {

                            log += mapaOfId.get(key) + " request at " + LocalTime.now().toString().substring(0,12) + ": \"" + clientRequest +  "\"\n";

                            String twoDates[] = clientRequest.split(" ");

                            try
                            {
                                String dataOdDataDo = Time.passed(twoDates[0], twoDates[1]);
                                channel.write(ByteBuffer.wrap(dataOdDataDo.getBytes()));
                                mapaInfo.put(key, mapaInfo.get(key) + "Request: " + clientRequest + "\nResult: \n" + dataOdDataDo + "\n");
                            }
                            catch(IOException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else if(clientRequest.equals("bye"))
                        {
                            try
                            {
                                channel.write(ByteBuffer.wrap("logged out".getBytes()));
                                mapaInfo.put(key, mapaInfo.get(key) + "logged out ");
                            }
                            catch(IOException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else if(clientRequest.contains("bye and log transfer"))
                        {
                            log += mapaOfId.get(key) + " logged out at " + LocalTime.now().toString().substring(0,12) + "\n";

                            mapaInfo.put(key, mapaInfo.get(key) + "logged out\n=== " +  mapaOfId.get(key) + " log end ===\n");

                            try
                            {
                                channel.write(ByteBuffer.wrap(mapaInfo.get(key).getBytes()));
                                channel.close();
                                channel.socket().close();
                            }
                            catch(IOException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
        }
    }

}
