/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CustomersPurchaseSortFind {
    List<Purchase> listaZakup = new ArrayList<>();


    public void readFile(String plik){
            FileReader fr;
            try {
                fr = new FileReader((String) plik);
                BufferedReader reader = new BufferedReader(fr);
                String line = reader.readLine();
                while (line != null) {
                    listaZakup.add(new Purchase(
                            line.split("\\;")[0],
                            line.split("\\;")[1],
                            line.split("\\;")[2],
                            Double.parseDouble(line.split("\\;")[3]),
                            Double.parseDouble(line.split("\\;")[4])
                            )
                    );
                    line =  reader.readLine();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            boolean c1 = false,c2 = false;

            for (Purchase p : listaZakup){
                if (p.index.equals("c00001"))
                    c1 = true;
                if (p.index.equals("c00002"))
                    c2 = true;
            }
            if (c1 == false || c2 == false)
                System.out.println("W pliku nie ma klientow : c00001 albo c00002");
    }

    public void showSortedBy(String sort){
        System.out.println(sort);
        List<Purchase> listaSorted = new ArrayList<>(listaZakup);
        String suma;
        Purchase steel = null;
        if (sort.equals("Nazwiska")){
            char max;
            for (int i = 0; i < listaSorted.size() - 1; i++) {
                for (int j = 0; j < listaSorted.size()- i -1; j++) {
                    for (int k = 0,u = 1; k < u; k++) {
                        int size;
                        if(Integer.compare(listaSorted.get(j).nazwisko.length(),listaSorted.get(j+1).nazwisko.length()) < 0)
                            size = listaSorted.get(j).nazwisko.length();
                        else
                            size = listaSorted.get(j+1).nazwisko.length();
                        if ( k < size && listaSorted.get(j).nazwisko.charAt(k) > listaSorted.get(j + 1).nazwisko.charAt(k) ){
                            steel = listaSorted.get(j);
                            listaSorted.set(j,listaSorted.get(j+1));
                            listaSorted.set(j+1,steel);
                        }else if( k < size && listaSorted.get(j).nazwisko.charAt(k) == listaSorted.get(j + 1).nazwisko.charAt(k))
                            u++;

                    }
                    if (listaSorted.get(j).nazwisko.charAt(0) == listaSorted.get(j+1).nazwisko.charAt(0)){
                        if (listaSorted.get(j+1).numerIndeksu() < listaSorted.get(j).numerIndeksu()){
                            steel = listaSorted.get(j);
                            listaSorted.set(j,listaSorted.get(j+1));
                            listaSorted.set(j+1,steel);
                        }
                    }
                }
            }
            for (Purchase p : listaSorted)
                System.out.println(p);

        }else {
            for (int i = 0; i < listaSorted.size() - 1; i++) {
                for (int j = 0; j < listaSorted.size()- i -1; j++) {
                    if (listaSorted.get(j).koszty() < listaSorted.get(j + 1).koszty() ){
                        steel = listaSorted.get(j);
                        listaSorted.set(j,listaSorted.get(j+1));
                        listaSorted.set(j+1,steel);

                    }
                    if (listaSorted.get(j).koszty() == listaSorted.get(j+1).koszty()){
                        if (listaSorted.get(j+1).numerIndeksu() < listaSorted.get(j).numerIndeksu()){
                            steel = listaSorted.get(j);
                            listaSorted.set(j,listaSorted.get(j+1));
                            listaSorted.set(j+1,steel);
                        }
                    }
                }
            }
            for (Purchase p : listaSorted)
                System.out.println(p + p.kosztyNapis());
        }
        System.out.println("");
    }

    public void showPurchaseFor(String index){
        System.out.println("Klient " + index);
        for (int i = 0; i < listaZakup.size(); i++) {
            if (listaZakup.get(i).index.equals(index))
                System.out.println(listaZakup.get(i));
        }

        System.out.println("");
    }
}
