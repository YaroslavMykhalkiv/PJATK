/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;
import java.io.*;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
  static int maxSize = 0;
  private static String sort(String s) {
    return Stream.of(s.split("")).sorted().collect(Collectors.joining());
  }
  public static void main(String[] args) throws IOException {
    Map<String, List<String>> map = new BufferedReader(
            new BufferedReader(new InputStreamReader( new URL(" http://wiki.puzzlers.org/pub/wordlists/unixdict.txt").openConnection().getInputStream())))
            .lines()
            .sorted()
            .collect(Collectors.groupingBy(Main::sort));
    map.forEach((e,x)->{
      x.remove(e);
      if (maxSize < x.size())
        maxSize = x.size();
    });
    map.entrySet().stream().filter(list -> list.getValue().size() == maxSize)
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)).entrySet().stream().sorted(Map.Entry.comparingByKey())
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (x, y) -> x, LinkedHashMap::new))
            .forEach((key, val) -> System.out.println(key + " " + val));
  }
}
