/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad2;


import zad1.Purchase;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.*;

public class Anagrams {
    List<String> listaAnagrams = new ArrayList<>();

    public Anagrams(String plik) {
        FileReader fr;
        String line = "";
        String text = "";
        try {
            fr = new FileReader((String) plik);
            BufferedReader reader = new BufferedReader(fr);
            line = reader.readLine();
            while (line != null) {
                text += line + " ";
                line = reader.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        listaAnagrams = Arrays.asList(text.split("\\s"));
    }

    public List<List<String>> getSortedByAnQty(){
        List<List<String>> listaList = new ArrayList<>();
        for (int i = 0; i < listaAnagrams.size() - 1; i++) {
            List<String> lista = new ArrayList<>();
            boolean isContain = false;
            lista.add(listaAnagrams.get(i));
            for (int j = i + 1; j < listaAnagrams.size(); j++) {//szuka anagramy
                String first = Anagrams.sort(listaAnagrams.get(i));
                String second = Anagrams.sort(listaAnagrams.get(j));
                if (first.equals(second))
                    lista.add(listaAnagrams.get(j));
            }

            for (int j = 0; j < listaList.size(); j++) {//szuka w "listaList" zawierajaca elementy w liscie "lista"
                for (int k = 0; k < listaList.get(j).size(); k++) {
                    for (int l = 0; l < lista.size(); l++) {
                        if (listaList.get(j).get(k).equals(lista.get(l)))
                            isContain = true;
                    }
                }
            }

            for (int j = 0; j < lista.size()-1; j++) {//sortuje liste "lista" w porządku alfabetycznym pierwszego słowa na liście
                for (int k = 0,u = 1; k < u; k++) {
                    int size;
                    if(Integer.compare(lista.get(j).length(),lista.get(j+1).length()) < 0)
                        size = lista.get(j).length();
                    else
                        size = lista.get(j+1).length();
                    if ( k < size && lista.get(j).charAt(k) > lista.get(j+1).charAt(k) ){
                        Collections.swap(lista, j, j + 1);
                    }else if( k < size && lista.get(j).charAt(k) == lista.get(j+1).charAt(k))
                        u++;
                }
            }

            for (int j = 0; j < listaList.size(); j++) {//sortuje liste "listaList" w porządku liczby anagramów
                if (j != listaList.size() - 1 && listaList.get(j).size() < listaList.get(j + 1).size())
                    Collections.swap(listaList, j, j + 1);
                if (j != listaList.size() - 1 && listaList.get(j).size() == listaList.get(j + 1).size()){
                    for (int k = 0,u = 1; k < u; k++) {
                        int size;
                        if(Integer.compare(listaList.get(j).get(0).length(),listaList.get(j+1).get(0).length()) < 0)
                            size = listaList.get(j).get(0).length();
                        else
                            size = listaList.get(j+1).get(0).length();
                        if ( k < size && listaList.get(j).get(0).charAt(k) > listaList.get(j + 1).get(0).charAt(k) ){
                            Collections.swap(listaList, j, j + 1);
                        }else if( k < size && listaList.get(j).get(0).charAt(k) == listaList.get(j + 1).get(0).charAt(k))
                            u++;
                    }
                }

            }

            if (isContain == false)
                listaList.add(lista);
        }
        return  listaList;
    }

    public String getAnagramsFor(String word){
        List<List<String>> listaList = new ArrayList<>(this.getSortedByAnQty());
        List<String> lista = null;
        for (int i = 0; i < listaList.size(); i++) {
            for (int j = 0; j < listaList.get(i).size(); j++) {
                String first = Anagrams.sort(word);
                String second = Anagrams.sort(listaList.get(i).get(j));
                if (first.equals(second)){
                    lista = listaList.get(i);
                }
                if (listaList.get(i).contains(word)){
                    listaList.get(i).remove(word);
                    lista = listaList.get(i);
                }
            }
            if (listaList.get(i).contains(word)){
                listaList.get(i).remove(word);
                lista = listaList.get(i);
            }
        }
        return word + ": " + lista;
    }

    public static String sort(String text){
        char[]tab = text.toCharArray();
        for (int k = 0; k < tab.length; k++) {
            for (int l = 0; l < tab.length - k - 1; l++) {
                if (tab[l] > tab[l+1] ) {
                    char tmp = tab[l];
                    tab[l] = tab[l+1];
                    tab[l+1] = tmp;
                }
            }
        }
        return new String(tab);
    }
}  
