/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


public interface Selector<X> { // Uwaga: interfejs musi być sparametrtyzowany
    public boolean select(X x);
}