package project1;
public class TooManyThingsException extends Exception {
    public TooManyThingsException(String msg){
        super(msg);
    }
}
