/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import org.json.JSONObject;

import javax.swing.*;
import java.awt.*;

public class Main {

  public static void main(String[] args) {
    Service s = new Service("UNITED STATES OF AMERICA");
    String weatherJson = s.getWeather("New York");
    Double rate1 = s.getRateFor("USD");
    Double rate2 = s.getNBPRate();
    // ...
    // część uruchamiająca GUI

    String result = "";
    JSONObject jsonObject = new JSONObject(weatherJson);
    String country = jsonObject.getJSONObject("sys").getString("country");
    result += "Information about " + jsonObject.getString("name") +"(" + country + "):\n";
    result += "Current temperature: " + jsonObject.getJSONObject("main").getDouble("temp") + "\n";
    result += "Current Humidity: " + jsonObject.getJSONObject("main").getInt("humidity") + "\n";
    result += "Wind speed: " + jsonObject.getJSONObject("wind").getInt("speed") + "\n";
    result += "Wind angle: " + jsonObject.getJSONObject("wind").getInt("deg") + "\n\n";
    result += "Information about the exchange rate\n" +
            " of the " + country + "'s currency against the\n" +
            " currency specified by the user = " + rate1 + "\n\n";
    if (rate2 != 0)
      result +="Information on the exchange rate\n" +
              " of the zloty NBP against this\n" +
              " currency of the specified country = " + rate2;
    else
      result +="Didn't find a course in NBP for " + country + "'s currency";


    JFrame frame = new JFrame();
    JTextArea allText = new JTextArea(result);
    Font font = new Font("BMW1", Font.BOLD, 30);
    allText.setFont(font);
    frame.setTitle("Transport Task");
    frame.setSize(new Dimension(700, 700));
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    allText.setColumns(20);
    allText.setRows(5);

    frame.add(allText);
    frame.setVisible(true);


  }
}
