package com.example.pro1prm

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import com.example.pro1prm.databinding.FragmentDetailsBinding
import com.github.mikephil.charting.components.Description
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import java.time.LocalDate
import java.time.temporal.ChronoField


class DetailsFragment : Fragment() {

    private lateinit var binding: FragmentDetailsBinding

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return FragmentDetailsBinding.inflate(inflater, container, false).also {
            binding = it
        }.root
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val bundle = arguments
        val name = bundle?.get("Name").toString()
        val percent = bundle?.get("Percent").toString()
        val priority = bundle?.get("Priority").toString()
        val deadline = bundle?.get("Deadline").toString()
        val daysLeft = bundle?.get("DaysLeft").toString()

        binding.nameTask.text = name
        binding.priorityTask.text = priority
        binding.percentTask.setText(percent)
        binding.deadlineTask.text = deadline
        binding.daysLeftTask.text = daysLeft

        //binding.pieChart.setUsePercentValues(true)
        val MY_COLORS = intArrayOf(
            Color.rgb(150, 0, 0),
            Color.rgb(0, 150, 0),
        )

        val colors = ArrayList<Int>()

        for (c in MY_COLORS) colors.add(c)

        var list = ArrayList<PieEntry>()
        list.add(PieEntry(100 - percent.toFloat()))
        list.add(PieEntry(percent.toFloat()))
        var dataset = PieDataSet(list,"Done")
        dataset.setColors(colors)
        var des = Description()
        des.text = ""
        des.textSize=0f
        binding.pieChart.data = PieData(dataset)
        binding.pieChart.description = des




        binding.edit.setOnClickListener {
            val edit = EditAddFragment(EditAddFragment.Type.Edit)
            edit.arguments = arguments
            (activity as? Navigable)?.navigate(edit)
        }

        binding.save.setOnClickListener{
            val newTask = Task(
                name,
                priority,
                (LocalDate.parse(deadline).getLong(ChronoField.DAY_OF_YEAR) - DataSource.curDate).toString(),
                binding.percentTask.text.toString().toInt(),
                LocalDate.parse(deadline)
            )
            DataSource.tasks.add(newTask)
            (activity as? Navigable)?.navigate(Navigable.Destination.List)
        }

    }

}