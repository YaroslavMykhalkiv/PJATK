const { resume } = require('../config/mysql2/db');
const RoomRepository = require('../repository/mysql2/RoomRepository');

exports.showRoomList = (req, res, next) =>{
	RoomRepository.getRooms()
		.then(rooms => {
			res.render('pages/pokoj/list-room',{
				rooms: rooms,
				navLocation: 'room'
			});
		});
}
exports.showAddRoomForm = (req, res, next) =>{
	res.render('pages/pokoj/form-room',{
		room: {},
		pageTitle: 'Nowy pokoj',
		formMode: 'createNew',
		btnLabel: 'Dodaj pokoj',
		formAction: '/room/add',
		navLocation: 'room',
		validationErrors: []
	});
}
exports.showRoomForm = (req, res, next) =>{
	const roomId = req.params.roomId;
	RoomRepository.getRoomById(roomId)
		.then(room => {
			res.render('pages/pokoj/form-room',{
				room: room,
				pageTitle: 'Edycja pokoju',
				formMode: 'edit',
				btnLabel: 'Edytuj pokoj',
				formAction: '/room/edit',
				navLocation: 'room',
				validationErrors: []
			})
		});
}
exports.showRoomDetails = (req, res, next) =>{
	const roomId = req.params.roomId;
	RoomRepository.getRoomById(roomId)
		.then(room => {
			res.render('pages/pokoj/form-room',{
				room: room,
				pageTitle: 'Sczegoly pokoju',
				formMode: 'showDetails',
				formAction: '',
				navLocation: 'room',
				validationErrors: []
			})
		});
}

exports.addRoom = (req, res, next) => {
	 const roomData = { ...req.body};
	 RoomRepository.createRoom(roomData)
	 	.then(result => {
			 res.redirect('/room');
		 })
		 .catch(err => { 
			res.render('pages/pokoj/form-room',{
				room: roomData, 
				pageTitle: 'Nowy pokoj',
				formMode: 'createNew',
				btnLabel: 'Dodaj pokoj',
				formAction: '/room/add',
				navLocation: 'room',
				validationErrors: err.details 
			});
		});
};
exports.updateRoom = (req, res, next) => {
	const roomId = req.body._idRoom;
	const roomData = { ...req.body};
	RoomRepository.updateRoom(roomId, roomData)
		.then(result => {
			res.redirect('/room');
		})
		.catch(err => { 
			RoomRepository.getRoomById(roomId)
				.then(room => {
					room.number = roomData.number;
					room.level = roomData.level;
					room.quantity = roomData.quantity;
					res.render('pages/pokoj/form-room',{
						room: room,
						pageTitle: 'Edycja pokoju',
						formMode: 'edit',
						btnLabel: 'Edytuj pokoj',
						formAction: '/room/edit',
						navLocation: 'room',
						validationErrors: err.details 
					})
				});
		});
};
exports.deleteRoom = (req, res, next) => {
	const roomId = req.params.roomId;
	RoomRepository.deleteRoom(roomId)
		.then(() => {
			res.redirect('/room');
		});
};