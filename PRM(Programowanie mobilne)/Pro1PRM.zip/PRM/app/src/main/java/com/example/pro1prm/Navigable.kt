package com.example.pro1prm

import android.os.Bundle

interface Navigable {
    enum class Destination{
        List, Add, Details
    }
    fun navigate(det: DetailsFragment)
    fun navigate(to: Destination)
    fun navigate(edit: EditAddFragment)
}