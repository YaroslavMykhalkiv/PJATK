package com.example.pro1prm

import androidx.annotation.DrawableRes
import java.io.Serializable
import java.time.LocalDate

data class Task(
    val name: String,
    val priority: String,
    val timeLeft: String,
    val percent: Int,
    val deadline: LocalDate
)
