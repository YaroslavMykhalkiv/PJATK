package Zadanie3.A;

import org.apache.derby.client.am.SqlException;

import java.sql.*;

public class Ins1 {

    static public void main(String[] args) {
        new Ins1();
    }

    Statement stmt;

    Ins1() {
        Connection con = null;
        String url = "jdbc:derby:C:\\drb\\ksidb";
        try {
            //...
            con = DriverManager.getConnection(url);
            stmt = con.createStatement();
        } catch (Exception exc) {
            System.out.println(exc);
            System.exit(1);
        }
        // nazwy wydawców do wpisywania do tabeli
        String[] wyd = {"PWN", "PWE", "Czytelnik", "Amber", "HELION", "MIKOM"};

        // pierwszy numer wydawcy do wpisywania do tabeli: PWN ma numer 15, PWE ma 16, ...
        int beginKey = 15;

        String[] ins = {"insert into wydawca(WYDID , name) " +
                " values(","')"};// ? ... tablica instrukcji SQL do wpisywania rekordów do tabeli: INSERT ...

        int insCount = 0;   // ile rekordów wpisano
        try {
            for (int i = 0; i < wyd.length; i++) {
//                System.out.println(ins[0] + beginKey + ",'"+ wyd[i] + ins[1]);
                stmt.executeUpdate(ins[0] + beginKey++ + ",'" + wyd[i] + ins[1]);
                insCount++;
            }// wpisywanie rekordów
        }catch (SQLException exc) {
            System.out.println("SQL except.: " + exc.getMessage());
            System.out.println("SQL state  : " + exc.getSQLState());
            System.out.println("Vendor errc: " + exc.getErrorCode());
            //System.exit(1);
        } finally {
            try {
                System.out.println("Do tabeli wpisano " + insCount + " rekordow");
                stmt.close();
                con.close();
            } catch (SQLException exc) {
                System.out.println(exc);
                System.exit(1);
            }
        }
    }
}