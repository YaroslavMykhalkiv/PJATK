package zad1.B;

import java.text.DecimalFormat;


public class Consumer implements Runnable{
    Buffer b;


    public Consumer(Buffer b){
        this.b = b;

    }

    @Override
    public void run() {
        while (true){
            b.get();
            long x = Long.parseLong(new DecimalFormat("#0").format(Math.random()*2000 + 1));
            try {
                Thread.sleep(x);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
