package zad2;

public class A extends Klass{
    boolean f;

    public A(boolean f , int b){
        super(b);
        this.f = f;
    }

}
