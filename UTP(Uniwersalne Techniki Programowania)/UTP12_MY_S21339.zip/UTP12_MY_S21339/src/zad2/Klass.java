package zad2;

public class Klass {
    int a;
    final int b;
    public Klass(int b){
        this.b = b;
    }
    public Klass(){
        b = 45;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }



}
