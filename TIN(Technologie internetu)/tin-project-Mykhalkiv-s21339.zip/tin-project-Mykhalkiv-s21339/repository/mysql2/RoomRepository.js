const db = require('../../config/mysql2/db');
const roomSchema = require('../../model/joi/Room');

exports.getRooms = () => {
    return db.promise().query('Select * from Pokoj')
        .then((results,fields) => {
            console.log(results[0]);
            return results[0];
        })
        .catch(err =>{
            console.log(err);
            throw err;
        });

};
exports.getRoomById = (roomId) =>{
    const query = `select _idRoom,number,level,quantity,_idSchedule,time_start,time_end,done, _idEmp,firstname,lastname,salary
        from Pokoj r
        left join Grafik g on  g.room_id = r._idRoom 
        left join Pracownik p on g.emp_id = p._idEmp
        where r._idRoom = ?`;
         return db.promise().query(query,[roomId])
        .then((results,fields)=>{
            const firstRow = results[0][0];
            if(!firstRow){
                return {};
            }
            const room = {
                _idRoom: parseInt(roomId),
                number: firstRow.number,
                level: firstRow.level,
                quantity: firstRow.quantity,
                schedules: []
            };
            for(let i = 0; i < results[0].length;i++){
                const row = results[0][i];
                if(row._idSchedule){
                    const schedules = {
                        _idSchedule: row._idSchedule,
                        time_start: row.time_start,
                        time_end: row.time_end,
                        done: row.done,
                        emp: {
                            _idEmp: row._idEmp,
                            firstname: row.firstname,
                            lastname: row.lastname,
                            salary: row.salary,
                        }
                    };
                    room.schedules.push(schedules);
                }
            }
            return room;
        })
        .catch(err =>{
            console.log(err);
            throw err;
        });
};
exports.createRoom= (newRoomData) =>{
    const vRes = roomSchema.validate(newRoomData, { abortEarly: false} );
    if(vRes.error) {
        return Promise.reject(vRes.error);
    }
    const number = newRoomData.number;
    const level = newRoomData.level;
    const quantity = newRoomData.quantity;
    const sql = 'insert into Pokoj (number,level,quantity) values (?,?,?)';
    return db.promise().execute(sql,[number,level,quantity]);

};
exports.updateRoom = (roomId,roomData) =>{
    const vRes = roomSchema.validate(roomData, { abortEarly: false} );
    if(vRes.error) {
        return Promise.reject(vRes.error);
    }
    const number = roomData.number;
    const level = roomData.level;
    const quantity = roomData.quantity;
    const sql = 'Update Pokoj set number = ?,level = ?,quantity = ? where _idRoom = ?';
    return db.promise().execute(sql,[number,level,quantity,roomId]);
};
exports.deleteRoom = (roomId) =>{
    const sql1 = 'Delete from Grafik where room_id = ?';
    const sql2 = 'Delete from Pokoj where _idRoom = ?';

    return db.promise().execute(sql1,[roomId])
        .then(()=>{
            return db.promise().execute(sql2,[roomId]);
        });
};