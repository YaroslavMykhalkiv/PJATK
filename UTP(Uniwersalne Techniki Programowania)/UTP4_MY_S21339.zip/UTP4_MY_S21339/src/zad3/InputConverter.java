package zad3;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class InputConverter<T> {
    T text;
    InputConverter(T plik){
        String str = "";
        if (plik.getClass() == String.class ) {
            FileReader fr;
            int c;
            try {
                fr = new FileReader((String) plik);
                BufferedReader reader = new BufferedReader(fr);
                String line = reader.readLine();
                while (line != null) {
                    str += line + "\n";
                    line =  reader.readLine();
                }
                text = (T) str;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else
        text = plik;
    }

     <R>R convertBy(Function<?,?> ... tab){
        Object wynik = text;
        for (int i = 0; i < tab.length; i++) {
            Function f = tab[i];
            wynik = f.apply(wynik);
        }
        return  (R)wynik;
    }

//    public <Q, R> Q andThen(Function<T,R> func1, Function<R,Q> func2){
//        Function<T,Q> wynik = func1.andThen((Function<? super R, ? extends Q>) func2);
//        return wynik;
//    }
}
