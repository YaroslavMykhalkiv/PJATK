const { resume } = require('../config/mysql2/db');
const EmpRepository = require('../repository/mysql2/EmpRepository');

exports.showEmpList = (req, res, next) =>{
	EmpRepository.getEmps()
		.then(emps => {
			res.render('pages/pracownik/list',{
				emps: emps,
				navLocation: 'emp'
			});
		});
}
exports.showAddEmpForm = (req, res, next) =>{
	res.render('pages/pracownik/form',{
		emp: {},
		pageTitle: 'Nowy pracownik',
		formMode: 'createNew',
		btnLabel: 'Dodaj pracownika',
		formAction: '/emp/add',
		navLocation: 'emp',
		validationErrors: []
	});
}
exports.showEmpForm = (req, res, next) =>{
	const empId = req.params.empId;
	EmpRepository.getEmpById(empId)
		.then(emp => {
			res.render('pages/pracownik/form',{
				emp: emp,
				pageTitle: 'Edycja pracownika',
				formMode: 'edit',
				btnLabel: 'Edytuj pracownika',
				formAction: '/emp/edit',
				navLocation: 'emp',
				validationErrors: []
			})
		});
}
exports.showEmpDetails = (req, res, next) =>{
	const empId = req.params.empId;
	EmpRepository.getEmpById(empId)
		.then(emp => {
			res.render('pages/pracownik/form',{
				emp: emp,
				pageTitle: 'Sczegoly pracownika',
				formMode: 'showDetails',
				formAction: '',
				navLocation: 'emp',
				validationErrors: []

			})
		});
}

exports.addEmp = (req, res, next) => {
	 const empData = { ...req.body};
	 EmpRepository.createEmp(empData)
	 	.then(result => {
			 res.redirect('/emp');
		 })
		 .catch(err => { 
			res.render('pages/pracownik/form',{
				emp: empData, 
				pageTitle: 'Dodawanie pracownika', 
				formMode: 'createNew', 
				btnLabel: 'Dodaj pracownika', 
				formAction: '/emp/add', 
				navLocation: 'emp', 
				validationErrors: err.details 
			});
		});
};
exports.updateEmp = (req, res, next) => {
	const empId = req.body._idEmp;
	const empData = { ...req.body};
	EmpRepository.updateEmp(empId, empData)
		.then(result => {
			res.redirect('/emp');
		})
		.catch(err => { 
			EmpRepository.getEmpById(empId)
				.then(emp => {
					emp.firstName = empData.firstName;
					emp.lastName = empData.lastName;
					emp.salary = empData.salary;
					res.render('pages/pracownik/form',{
						emp: emp,
						pageTitle: 'Edycja pracownika',
						formMode: 'edit',
						btnLabel: 'Edytuj pracownika',
						formAction: '/emp/edit',
						navLocation: 'emp',
						validationErrors: err.details 
					})
				});		
		});
};
exports.deleteEmp = (req, res, next) => {
	const empId = req.params.empId;
		EmpRepository.deleteEmp(empId)
		.then(() => {
			res.redirect('/emp');
		});
};