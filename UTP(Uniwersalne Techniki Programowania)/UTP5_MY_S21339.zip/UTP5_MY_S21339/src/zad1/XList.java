package zad1;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Function;

public class XList<T> extends ArrayList {


    public XList(T ... t){
        for(T z : t){
            if (z instanceof Collection)
                ((Collection) z).forEach(d -> this.add(d));
            else
                this.add(z);
        }
    }

    public XList(){}

    public static <T>XList of(T ... t){
        boolean isColl = false;
        if (t.length > 1) {
            isColl = true;
            for (T wrt : t) {
                if ((wrt instanceof Collection || wrt.getClass().isArray()) == false) {
                    isColl = false;
                   break;
                }
            }
        }
        XList tab = new XList<>();
        for (T wrt : t) {
            if (wrt instanceof Collection && !isColl) {
                ((Collection) wrt).forEach(o -> tab.addAll(XList.of(o)));
            } else if (wrt.getClass().isArray() && !isColl) {
                Arrays.stream(((Object[]) wrt)).forEach(o -> tab.addAll(XList.of(o)));
            } else {
                if (isColl) {
                    tab.add(XList.of(wrt));
                } else {
                    tab.add(wrt);
                }
            }
        }
        return tab;
    }

    public static <T>XList<T> charsOf(String str){
        XList<T> tab = new XList();
        for (int i = 0; i < str.length(); i++) {
            tab.add(str.charAt(i));
        }
        return tab;
    }

    public static <T>XList<T> tokensOf(String ... str){
        XList<T> tab = new XList();
        String regex = "\\s";
        if (str.length == 2) {
            regex = str[1];
        }
        return new XList(str[0].split(regex));
    }

    public XList<T> union(Object...tab){
        XList<T> tabl = new XList(tab);
        XList<T> arr = new XList<>();
        for (int i = 0; i < this.size(); i++) {
                arr.add(this.get(i));
        }
        for (int i = 0; i <tabl.size()  ; i++) {
            arr.add(tabl.get(i));
        }
        return arr;
    }

    public XList<T> diff(Object...tab){
        XList<T> tabl = new XList(tab);
        XList<T> arr = new XList(this);
        for (int i = 0; i < tabl.size(); i++) {
            for (int j = 0; j < arr.size(); j++) {
                arr.remove(tabl.get(i));
            }
        }
        return arr;
    }

    public XList<T> unique(){
        XList<T> tabl = new XList(this);
        for (int i = 0; i < tabl.size(); i++) {
            for (int j = i+1; j < tabl.size(); j++) {
                if (tabl.get(i) == tabl.get(j)) {
                    tabl.remove(j);
                    j--;
                }
            }
        }
        return tabl;
    }

//    public XList<XList<T>> combine(){
//        XList<XList<T>> toCombine = (XList<XList<T>>)this;
//        XList<XList<T>> xList = new XList<>();
//        int sum=1;
//        return xList;
//    }
//
//    public <R>XList<R> collect(Function<XList<T>, String> function){
//        XList lista = new XList<>();
//        XList<XList<String>>list = XList.of(this);
//        System.out.println(list+"sdsdfsd");
//        for (XList<String> tab : this) {
//            lista.add(function.apply(tab));
//        }
//        return lista;
//    }
//
//    public String join(String... regex){
//        String text = "";
//        if (regex.length == 0) {
//            regex = new String[]{""};
//        }
//        for (int i = 0; i < this.size(); i++) {
//            text += this.get(i);
//            if (i != this.size()-1)
//                text +=  regex[0];
//        }
//        return text;
//    }

    public void forEachWithIndex(BiConsumer<T, Integer> biCon){
        for (int i = 0, j = 0; i < this.size(); i++, j++) {
            biCon.accept((T) this.get(i), i);
            for (int k = 0; k < this.size(); k++) {
            }
        }
    }
}
