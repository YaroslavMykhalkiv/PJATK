const express = require('express');
const router = express.Router();

const empApiController = require('../../api/EmpAPI');

router.get('/', empApiController.getEmps);
router.get('/:empId', empApiController.getEmpById);
router.post('/', empApiController.createEmp);
router.put('/:empId', empApiController.updateEmp);
router.delete('/:empId', empApiController.deleteEmp);

module.exports = router;