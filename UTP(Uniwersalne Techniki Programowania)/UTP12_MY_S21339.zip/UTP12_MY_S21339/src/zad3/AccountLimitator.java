package zad3;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;

public class AccountLimitator implements VetoableChangeListener {
    int limit;

    public AccountLimitator(int limit){
        this.limit = limit;
    }

    @Override
    public void vetoableChange(PropertyChangeEvent propertyChangeEvent) throws PropertyVetoException {
        if((double)propertyChangeEvent.getNewValue() < limit){
            throw new PropertyVetoException(propertyChangeEvent.getPropertyName() + ": Unacceptable value change: " + (double)propertyChangeEvent.getNewValue(),propertyChangeEvent);
        }
    }
}
