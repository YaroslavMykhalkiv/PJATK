
const { resume } = require('../config/mysql2/db');
const GrafikRepository = require('../repository/mysql2/GrafikRepository');
const EmpRepository =  require('../repository/mysql2/EmpRepository');
const RoomRepository =  require('../repository/mysql2/RoomRepository');

exports.showGrafikList = (req, res, next) =>{
	GrafikRepository.getSchedules()
		.then(schedules => {
			res.render('pages/grafik_sprzatan/list-grafik',{
				schedules: schedules,
				navLocation: 'grafik'
			});
		});
}
exports.showAddScheduleForm = (req, res, next) =>{
	let allEmps, allRooms;
	EmpRepository.getEmps()
		.then(emps => {
			allEmps = emps;
			return RoomRepository.getRooms();
		})
		.then(rooms => {
			allRooms = rooms;
			res.render('pages/grafik_sprzatan/form-grafik',{
				schedule: {},
				pageTitle: 'Nowy grafik',
				formMode: 'createNew',
				allEmps: allEmps,
				allRooms: allRooms,
				btnLabel: 'Dodaj grafik',
				formAction: '/grafik/add',
				navLocation: 'grafik',
				validationErrors: [] 
			});
		});
	
}
exports.showScheduleForm = (req, res, next) =>{
	const grafikdId = req.params.grafikdId;
	let allEmps, allRooms;
	EmpRepository.getEmps()
		.then(emps => {
			allEmps = emps;
			return RoomRepository.getRooms();
		})
		.then(rooms => {
			allRooms = rooms;
			return GrafikRepository.getScheduleById(grafikdId);
			
		}).then(schedule => {
			res.render('pages/grafik_sprzatan/form-grafik',{
				schedule: schedule,
				pageTitle: 'Edycja grafiku',
				formMode: 'edit',
				allEmps: allEmps,
				allRooms: allRooms,
				btnLabel: 'Edytuj grafik',
				formAction: '/grafik/edit',
				navLocation: 'grafik',
				validationErrors: [] 
			});
		});
}
exports.showScheduleDetails = (req, res, next) =>{
	const grafikdId = req.params.grafikdId;
	let allEmps, allRooms;
	EmpRepository.getEmps()
		.then(emps => {
			allEmps = emps;
			return RoomRepository.getRooms();
		})
		.then(rooms => {
			allRooms = rooms;
			return GrafikRepository.getScheduleById(grafikdId);
			
		}).then(schedule => {
			res.render('pages/grafik_sprzatan/form-grafik',{
				schedule: schedule,
				pageTitle: 'Sczegoly grafiku',
				formMode: 'showDetails',
				allEmps: allEmps,
				allRooms: allRooms,
				formAction: '',
				navLocation: 'grafik',
				validationErrors: [] 

			});
		});
}

exports.addSchedule = (req, res, next) => {
	 const scheduleData = { ...req.body};
	 GrafikRepository.createSchedule(scheduleData)
	 	.then(result => {
			 res.redirect('/grafik');
		 })
		 .catch(err => { 
			let allEmps, allRooms;
			EmpRepository.getEmps()
				.then(emps => {
					allEmps = emps;
					return RoomRepository.getRooms();
				})
				.then(rooms => {
					allRooms = rooms;
					scheduleData._idSchedule = 1;
					res.render('pages/grafik_sprzatan/form-grafik',{
						schedule: scheduleData,
						pageTitle: 'Nowy grafik',
						formMode: 'createNew',
						allEmps: allEmps,
						allRooms: allRooms,
						btnLabel: 'Dodaj grafik',
						formAction: '/grafik/add',
						navLocation: 'grafik',
						validationErrors: err.details 
					});
				});
		});
};
exports.updateSchedule = (req, res, next) => {
	const scheduleId = req.body._idSchedule;
	const scheduleData = { ...req.body};
	GrafikRepository.updateSchedule(scheduleId, scheduleData)
		.then(result => {
			res.redirect('/grafik');
		})
		.catch(err => { 
			let allEmps, allRooms;
			EmpRepository.getEmps()
				.then(emps => {
					allEmps = emps;
					return RoomRepository.getRooms();
				})
				.then(rooms => {
					allRooms = rooms;
					return GrafikRepository.getScheduleById(scheduleId);
				}).then(schedule => {
					schedule.room_id = scheduleData.room_id;
					schedule.emp_id = scheduleData.emp_id;
					schedule.time_start = scheduleData.time_start;
					schedule.time_end = scheduleData.time_end;
					schedule.done = scheduleData.done;

					res.render('pages/grafik_sprzatan/form-grafik',{
						schedule: schedule,
						pageTitle: 'Edycja grafiku',
						formMode: 'edit',
						allEmps: allEmps,
						allRooms: allRooms,
						btnLabel: 'Edytuj grafik',
						formAction: '/grafik/edit',
						navLocation: 'grafik',
						validationErrors: err.details 
					});
				});
		});
};
exports.deleteSchedule = (req, res, next) => {
	const scheduleId = req.params.grafikdId;
	GrafikRepository.deleteSchedule(scheduleId)
		.then(() => {
			res.redirect('/grafik');
		});
};