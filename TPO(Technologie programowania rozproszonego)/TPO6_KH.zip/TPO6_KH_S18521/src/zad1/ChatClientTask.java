/**
 *
 *  @author Kunitskaya Hanna S18521
 *
 */

package zad1;


import java.util.List;
import java.util.concurrent.*;


public class ChatClientTask extends FutureTask<ChatClient> {

    public ChatClientTask(Callable<ChatClient> callable) {
        super(callable);
    }

    public static ChatClientTask create(ChatClient c, List<String> msgs, int wait) {

        return new ChatClientTask(() -> {
            c.login();

            if (wait != 0) { Thread.sleep(wait); }
            for (String message : msgs) {
                c.send(message);
                    if (wait != 0)  { Thread.sleep(wait); }
            }
            c.logout();

            if (wait != 0) { Thread.sleep(wait); }
            return c;
        });
    }

    public ChatClient getClient() {

        try {
            return this.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        return null;
    }
}
