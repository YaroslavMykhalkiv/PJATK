/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import java.util.ArrayList;
import java.util.List;
import java.util.function.ObjLongConsumer;

public class ListCreator { // Uwaga: klasa musi być sparametrtyzowana
    List list;
    List ready = new ArrayList();

    public ListCreator(List list){
        this.list = list;
    }
    public static ListCreator collectFrom (List list){
        return new ListCreator(list);
    }

    public ListCreator when(Selector selector){
        for(Object x : list){
            if (selector.select(x)) {
                ready.add(x);
            }
        }
        return this;
    }

    public List mapEvery(Mapper mapper){
        for (int i = 0; i < ready.size(); i++) {
            ready.set(i,mapper.map(ready.get(i)));
        }
        return ready;
    }
}  
