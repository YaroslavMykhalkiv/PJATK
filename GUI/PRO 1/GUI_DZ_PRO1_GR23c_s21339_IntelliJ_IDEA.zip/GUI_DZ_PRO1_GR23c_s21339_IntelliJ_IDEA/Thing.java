package project1;

public class Thing {
    String nazwaRzeczy;
    double objetosc;

    public Thing(String nazwaRzeczy, double objetosc){
        this.nazwaRzeczy = nazwaRzeczy;
        this.objetosc = objetosc;
    }
    public String toString(){
        return nazwaRzeczy + " zajmuje: " + objetosc;
    }
}
