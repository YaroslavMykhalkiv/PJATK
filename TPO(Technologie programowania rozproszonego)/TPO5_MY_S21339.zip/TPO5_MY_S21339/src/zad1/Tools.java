/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import org.yaml.snakeyaml.Yaml;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

public class Tools {
    static Options createOptionsFromYaml(String fileName) throws Exception{
        InputStream wczytywaniePliku = new FileInputStream(fileName);
        Yaml yamlObject = new Yaml();
        Map<String, Object> mapaYaml = yamlObject.load(wczytywaniePliku);
        return new Options((String) mapaYaml.get("host"),
                Integer.parseInt(String.valueOf(mapaYaml.get("port"))),
                Boolean.parseBoolean(String.valueOf(mapaYaml.get("concurMode"))),
                Boolean.parseBoolean(String.valueOf(mapaYaml.get("showSendRes"))),
                (Map<String, List<String>>)mapaYaml.get("clientsMap")
        );
    }
}
