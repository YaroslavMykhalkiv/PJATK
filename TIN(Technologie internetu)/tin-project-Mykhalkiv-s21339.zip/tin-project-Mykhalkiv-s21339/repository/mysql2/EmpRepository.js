const db = require('../../config/mysql2/db');
const empSchema = require('../../model/joi/Emp');


exports.getEmps = () => {
    return db.promise().query('Select * from Pracownik')
        .then((results,fields) => {
            console.log(results[0]);
            return results[0];
        })
        .catch(err =>{
            console.log(err);
            throw err;
        });

};
exports.getEmpById = (empId) =>{
        const query = `select _idEmp,firstname,lastname,salary,_idSchedule,time_start,time_end,done,_idRoom,number,level,quantity 
        from Pracownik p
        left join Grafik g on g.emp_id = p._idEmp 
        left join Pokoj r on g.room_id = r._idRoom 
         where p._idEmp = ?`;
         return db.promise().query(query,[empId])
        .then((results,fields)=>{

            const firstRow = results[0][0];
            if(!firstRow){
                return {};
            }
            const emp = {
                _idEmp: parseInt(empId),
                firstName: firstRow.firstname,
                lastName: firstRow.lastname,
                salary: firstRow.salary,
                schedules: []
            };
            for(let i = 0; i < results[0].length;i++){
                const row = results[0][i];
                if(row._idSchedule){
                    const schedules = {
                        _idSchedule: row._idSchedule,
                        time_start: row.time_start,
                        time_end: row.time_end,
                        done: row.done,
                        room: {
                            _idRoom: row._idRoom,
                            number: row.number,
                            level: row.level,
                            quantity: row.quantity,
                        }
                    };
                    emp.schedules.push(schedules);
                }
            }
            return emp;
        })
        .catch(err =>{
            console.log(err);
            throw err;
        });
};
exports.createEmp = (newEmpData) =>{
    const vRes = empSchema.validate(newEmpData, { abortEarly: false} );
    if(vRes.error) {
        return Promise.reject(vRes.error);
    }
    const firstname = newEmpData.firstName;
    const lastname = newEmpData.lastName;
    const salary = newEmpData.salary;
    const sql = 'insert into Pracownik (firstname,lastname,salary) values (?,?,?)';
    return db.promise().execute(sql,[firstname,lastname,salary]);

};
exports.updateEmp = (empId,empData) =>{
    const vRes = empSchema.validate(empData,{abortEarly: false});
    if(vRes.error){
        return Promise.reject(vRes.error);
    }
    const firstname = empData.firstName;
    const lastname = empData.lastName;
    const salary = empData.salary;
    const sql = 'Update Pracownik set firstname = ?,lastname = ?,salary = ? where _idEmp = ?';
    return db.promise().execute(sql,[firstname,lastname,salary,empId]);
};
exports.deleteEmp = (empId) =>{
    const sql1 = 'Delete from Grafik where emp_id = ?';
    const sql2 = 'Delete from Pracownik where _idEmp = ?';

    return db.promise().execute(sql1,[empId])
        .then(()=>{
            return db.promise().execute(sql2,[empId]);
        });
};