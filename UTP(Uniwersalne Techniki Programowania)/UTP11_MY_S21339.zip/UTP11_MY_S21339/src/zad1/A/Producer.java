package zad1.A;

import java.text.DecimalFormat;


public class Producer implements Runnable{
    Buffer b;


    public Producer(Buffer b){
        this.b = b;
    }

    @Override
    public void run() {
        while (true){
            int produkt = Integer.parseInt(new DecimalFormat("#0").format(Math.random()*1000 + 1));
            b.put(produkt);
            long x = Long.parseLong(new DecimalFormat("#0").format(Math.random()*2000 + 1));
            try {
                Thread.sleep(x);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
