/**
 *
 *  @author Kunitskaya Hanna S18521
 *
 */

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import static java.nio.channels.SelectionKey.OP_WRITE;

public class ChatServer {


    private String host;
    private boolean running;

    private Thread serverThread;
    private ServerSocketChannel serverSocketChannel;

    private Selector selector;
    private SelectionKey selectionKey;

    private StringBuilder serverLog;
    private static final Charset charset = StandardCharsets.UTF_8;

    private Map<SocketChannel, String> clientInfo;

    public ChatServer(String host, int port) {

        this.host = host;
        serverLog = new StringBuilder();
        clientInfo = new HashMap<>();

        try {

            serverSocketChannel = ServerSocketChannel.open();
            serverSocketChannel.configureBlocking(false);
            serverSocketChannel.socket().bind(new InetSocketAddress(host, port));
            System.out.println("Server started\n");

            selector = Selector.open();
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

        } catch (IOException ioe) {
            ioe.printStackTrace();
            System.exit(1);
        }
    }

    public void startServer() {

        running = true;

        Runnable task = () -> {
            try {
                while (running) {
                    selector.select();

                    Set keys = selector.selectedKeys();

                    Iterator iterator = keys.iterator();

                    while (iterator.hasNext()) {
                        selectionKey = (SelectionKey) iterator.next();
                        iterator.remove();

                        if (selectionKey.isAcceptable()) {
                            SocketChannel socketChannel = serverSocketChannel.accept();
                            socketChannel.configureBlocking(false);
                            socketChannel.register(selector, SelectionKey.OP_READ | OP_WRITE);
                        }

                        if (selectionKey.isReadable()) {
                            SocketChannel cc = (SocketChannel) selectionKey.channel();
                            communication(cc);
                        }
                        if (selectionKey.isWritable()) {
                            SocketChannel socketChannel = (SocketChannel) selectionKey.channel();
                        }
                    }
                }

            } catch (UnknownHostException exc) {

                System.err.println("Unknown host " + host);

            } catch (Exception exc) {

                exc.printStackTrace();
            }
        };

        serverThread = new Thread(task);
        serverThread.start();

    }


    public void communication(SocketChannel socketChannel) throws IOException, InterruptedException {
        ByteBuffer inByteBuffer = ByteBuffer.allocateDirect(1024);

        String request;


        inByteBuffer.clear();

        int readByte = socketChannel.read(inByteBuffer);

        if (readByte == 0) {
            Thread.sleep(200);

        } else if (readByte == -1) {
            serverSocketChannel.close();

        } else {
            String idClient = "";

            String serverLog;
            String clientLog;

            if (clientInfo.containsKey(socketChannel)) {

                idClient = clientInfo.get(socketChannel);
            }

            inByteBuffer.flip();
            CharBuffer buffer = charset.decode(inByteBuffer);
            request = buffer.toString();

            String[] content = request.split(" ");


            if (content[0].equals("xx")) {

                if (content[1].equals("login")) {

                    idClient = content[2].trim();
                    clientInfo.put(socketChannel, idClient);
                    clientLog = idClient + " logged in\n";
                    serverLog = LocalTime.now() + " " + clientLog;
                    this.serverLog.append(serverLog);
                } else {

                    clientLog = idClient + " logged out\n";
                    serverLog = LocalTime.now() + " " + clientLog;
                    this.serverLog.append(serverLog);
                    clientInfo.remove(socketChannel);

                }
            } else {
                clientLog = idClient + ": " + request + "\n";
                serverLog = LocalTime.now() + " " + clientLog;
                this.serverLog.append(serverLog);
            }

            for (SocketChannel client : clientInfo.keySet()) {
                sendLog(client, clientLog);
            }
        }
    }

    public void stopServer() {
        running = false;
        serverThread.interrupt();
        System.out.println("Server stopped");
    }

    private void sendLog(SocketChannel client, String message) throws IOException {
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(message.getBytes().length);

        byteBuffer.put(charset.encode(message));
        byteBuffer.flip();
        client.write(byteBuffer);
    }

    public String getServerLog() {
        return serverLog.toString();
    }
}
