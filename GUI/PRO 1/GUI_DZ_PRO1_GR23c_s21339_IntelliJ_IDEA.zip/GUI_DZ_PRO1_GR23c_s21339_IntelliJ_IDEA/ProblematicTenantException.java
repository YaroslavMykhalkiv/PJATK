package project1;

public class ProblematicTenantException extends Exception {
    public ProblematicTenantException(String msg){
        super(msg);
    }
}
