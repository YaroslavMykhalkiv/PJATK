package zad1;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class ListCreator<T> { // Uwaga: klasa musi być sparametrtyzowana
    List<T> list;
    List<T> ready = new ArrayList<T>();

    public ListCreator(List list){
        this.list = list;
    }
    public static <T>ListCreator collectFrom (List<T> list){
        return new ListCreator(list);
    }

    public ListCreator<T> when(Predicate<T> selector){
        for(Object x : list){
            if (selector.test((T) x)) {
                ready.add((T) x);
            }
        }
        return this;
    }

    public <R> List<T> mapEvery(Function<T,R> mapper){
        for (int i = 0; i < ready.size(); i++) {
            ready.set(i, (T) mapper.apply(ready.get(i)));
        }
        return ready;
    }
}
