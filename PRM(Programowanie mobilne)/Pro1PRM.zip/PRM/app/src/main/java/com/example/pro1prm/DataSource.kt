package com.example.pro1prm

import android.os.Build
import androidx.annotation.RequiresApi
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoField
import java.time.temporal.TemporalAdjusters
import java.time.temporal.WeekFields
import java.util.*
import kotlin.Comparator

object DataSource{

    @RequiresApi(Build.VERSION_CODES.O)
    public var curDate = LocalDate.now().getLong(ChronoField.DAY_OF_YEAR)


    private val myCustomComparator =  Comparator<Task> { a, b ->
        when {
            (a.priority == b.priority) -> 0
            (a.priority == "High") -> -1
            (a.priority == "Usual" && b.priority == "Low") -> -1
            (b.priority == "High") -> 1
            (b.priority == "Usual" && a.priority == "Low") -> 1
            else -> 1
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    var tasks = mutableListOf<Task>(
        Task(
            "Walk 1 sasdadhiandjknacsndnaowdawjdnsasdadhiandjknacsndnaowdawjdnsasdadhiandjknacsndnaowdawjdnsasdadhiandjknacsndnaowdawjdnsasdadhiandjknacsndnaowdawjdnsasdadhiandjknacsndnaowdawjdnsasdadhiandjknacsndnaowdawjdn",
            "High",
            (LocalDate.parse("2022-05-15").getLong(ChronoField.DAY_OF_YEAR) - curDate).toString(),
            0,
            LocalDate.parse("2022-05-15")
        ),Task(
            "Walk 1 ",
            "Low",
            (LocalDate.parse("2022-05-11").getLong(ChronoField.DAY_OF_YEAR) - curDate).toString(),
            40,
            LocalDate.parse("2022-05-11")
        ),Task(
            "Walk 1 ",
            "Usual",
            (LocalDate.parse("2022-05-10").getLong(ChronoField.DAY_OF_YEAR) - curDate).toString(),
            0,
            LocalDate.parse("2022-05-10")
        )
    )

    @RequiresApi(Build.VERSION_CODES.O)
    fun clearSortedList(): MutableList<Task> {
        tasks.forEach {
            if (it.deadline < LocalDate.now() || it.percent < 0 || it.percent >= 100)
            tasks.remove(it)
        }
        tasks.sortWith(myCustomComparator)
        tasks.sortBy { it.deadline }
        return tasks
    }


    @RequiresApi(Build.VERSION_CODES.O)
    fun getWeeksTasks(): Int {
        var count = 0;
        val now = LocalDate.now()
        val firstDayOfWeek: DayOfWeek = WeekFields.of(Locale.getDefault()).getFirstDayOfWeek()
        val lastDayOfWeek: DayOfWeek = firstDayOfWeek.plus(6)
        val endOfWeek = now.with(TemporalAdjusters.nextOrSame(lastDayOfWeek))
        tasks.forEach {
            if (it.deadline <= endOfWeek)count++
        }
        return count
    }
}