function validateForm(){
    const Id_pokoj = document.getElementById('room_id');
    const Id_pracownik = document.getElementById('emp_id');
    const czas_poczatku = document.getElementById('time_start');
    const czas_konczenia = document.getElementById('time_end');


    const errorId_pokoj = document.getElementById('errorId_pokoj');
    const errorId_pracownik = document.getElementById('errorId_pracownik');
    const errorCzas_poczatku = document.getElementById('errorCzas_poczatku');
    const errorCzas_konczenia = document.getElementById('errorCzas_konczenia');
    const errorSummary = document.getElementById('errorsSummary');
    let valid = true;

    resetErrors([Id_pokoj,Id_pracownik,czas_poczatku,czas_konczenia], [errorId_pokoj,errorId_pracownik,errorCzas_poczatku,errorCzas_konczenia],errorSummary);

    if(!checkRequired(Id_pokoj.value)){
        valid = false;
        Id_pokoj.classList.add("error-input");
        errorId_pokoj.innerText = "Pole jes wymagane";
    
    }

    if(!checkRequired(Id_pracownik.value)){
        valid = false;
        Id_pracownik.classList.add("error-input");
        errorId_pracownik.innerText = "Pole jes wymagane";
    
    }

    if(!checkRequired(czas_poczatku.value)){
        valid = false;
        czas_poczatku.classList.add("error-input");
        errorCzas_poczatku.innerText = "Pole jes wymagane";
    
    } else if(!checkTimeRange(czas_poczatku.value,"11:30","15:30")){
        valid = false;
        czas_poczatku.classList.add("error-input");
        errorCzas_poczatku.innerText = "Pole powinno byc w zakresie od 11:30 do 15:30";
    
    }

    if(!checkRequired(czas_konczenia.value)){
        valid = false;
        czas_konczenia.classList.add("error-input");
        errorCzas_konczenia.innerText = "Pole jes wymagane";
    
    } else if(!checkTimeRange(czas_konczenia.value,"12:00","16:00")){
        valid = false;
        czas_konczenia.classList.add("error-input");
        errorCzas_konczenia.innerText = "Pole powinno byc w zakresie od 12:00 do 16:00";
    
    }else if(!checkCorrektTime(czas_konczenia.value,czas_poczatku.value)){
        valid = false;
        czas_konczenia.classList.add("error-input");
        errorCzas_konczenia.innerText = "Pole powinno być o 30 lub 40 minut większe niż pole powyżej";
    
    }



    if(!valid){
        errorSummary.innerText = "Formularz zawiera bledy";
    }
    return valid;
}

