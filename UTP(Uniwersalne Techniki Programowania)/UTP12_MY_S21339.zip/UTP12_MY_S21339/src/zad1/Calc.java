/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Calc {
    Map<String , Method> mapa = new HashMap<>();

    public String doCalc(String str){

        Scanner sca = new Scanner(str);
        BigDecimal first = new BigDecimal(sca.next());
        String znak = sca.next();
        BigDecimal second = new BigDecimal(sca.next());
        System.out.println(first + znak + second);
        String wynik = "";
        try {
            MathAction action = new MathAction();
            Method add = action.getClass().getDeclaredMethod("add", BigDecimal.class,BigDecimal.class);
            Method divide = action.getClass().getDeclaredMethod("divide", BigDecimal.class,BigDecimal.class);
            Method multiply = action.getClass().getDeclaredMethod("multiply", BigDecimal.class,BigDecimal.class);
            Method subtract = action.getClass().getDeclaredMethod("subtract", BigDecimal.class,BigDecimal.class);
            mapa.put("+",add);
            mapa.put("-",subtract);
            mapa.put("*",multiply);
            mapa.put("/",divide);
            wynik = mapa.get(znak).invoke(action,first,second).toString();
            return wynik;
        } catch (Exception e){
            e.printStackTrace();
            return "Invalid command to calc";
        }
    }
}  
