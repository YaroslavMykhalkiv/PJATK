/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;

public class ChatClient {


    String id;
    String host;
    int port;
    SocketChannel clientSocketChannel;

    final int sizeBB = 1024;
    private final Charset ISO = Charset.forName("ISO-8859-2");
    ByteBuffer BB = ByteBuffer.allocate(sizeBB);

    String clientLog;


    public ChatClient(String host, int port, String id) {
        this.id = id;
        this.host = host;
        this.port = port;
    }

    public void login() {

        try {
            clientLog = "=== " + id + " chat view\n";
            clientSocketChannel = SocketChannel.open();
            clientSocketChannel.configureBlocking(false);
            clientSocketChannel.connect(new InetSocketAddress(host, port));

            while (!clientSocketChannel.finishConnect()) {
            }
            send("login " + id);

        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public void logout() {
        send("logout " + id);
    }

    public void send(String message) {
        try {
            ByteBuffer sendBuffer = ByteBuffer.allocateDirect(message.getBytes().length);
            sendBuffer.put(ISO.encode(message));
            sendBuffer.flip();
            clientSocketChannel.write(sendBuffer);
            Thread.sleep(5);

            clientSocketChannel.read(BB);
            BB.flip();
            String ms = ISO.decode(BB).toString();
            clientLog += ms;
            BB.clear();


        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }


    }

    public String getChatView() {
        return clientLog.toString();
    }


}
