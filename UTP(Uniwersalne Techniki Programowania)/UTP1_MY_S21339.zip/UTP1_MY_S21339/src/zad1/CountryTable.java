package zad1;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Iterator;

public class CountryTable extends JTable {
    String countriesFileName;
    public CountryTable(String countriesFileName) {
        this.countriesFileName = countriesFileName;
    }

    public CountryTable(DefaultTableModel model){
        super(model);
    }

    public JTable create() throws FileNotFoundException {
        BufferedReader reader = new BufferedReader(new FileReader(countriesFileName));
        Iterator<String> iterator = reader.lines().iterator();
        Object [][]countries = new Object[251][4];
        Object[] nazwyKolumn = new Object[4];
        int index = 0;
        while(iterator.hasNext()) {
            String[] subStr;
            subStr = iterator.next().split("\t");
            if (index == 0){
                nazwyKolumn[3] = subStr[0];
                nazwyKolumn[0] = subStr[1];
                nazwyKolumn[1] = subStr[2];
                nazwyKolumn[2] = subStr[3];
                subStr = iterator.next().split("\t");
            }
            countries[index][3] = new ImageIcon(new ImageIcon("data/" + subStr[0] + ".gif").getImage().getScaledInstance(40,20,3));
            countries[index][0] = subStr[1];
            countries[index][1] = subStr[2];
            countries[index][2] = Integer.valueOf(subStr[subStr.length - 1].split("\\s")[0]);
            index++;
        }
        DefaultTableModel model = new DefaultTableModel(countries, nazwyKolumn){
            @Override
            public boolean isCellEditable(int i, int i1) {
                if (i1 == 2)
                    return true;
                return false;
            }
            public Class getColumnClass(int column)
            {
                return getValueAt(0, column).getClass();
            }
        };
        CountryTable myTable = new CountryTable(model);
        myTable.getColumnModel().getColumn(2).setCellRenderer(new RedNumber());
//        myTable.setPreferredScrollableViewportSize(myTable.getPreferredSize());
        return myTable;
    }

}
