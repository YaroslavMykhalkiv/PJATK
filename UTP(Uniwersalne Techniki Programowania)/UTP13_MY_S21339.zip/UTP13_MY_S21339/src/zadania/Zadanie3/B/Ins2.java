package Zadanie3.B;

import java.sql.*;

public class Ins2 {

    static public void main(String[] args) {
        new Ins2();
    }

    PreparedStatement stmt;

    Ins2() {
        Connection con = null;
        String url = "jdbc:derby:C:\\drb\\ksidb";
        try {
            //...
            con = DriverManager.getConnection(url);
        } catch (Exception exc) {
            System.out.println(exc);
            System.exit(1);
        }
        // nazwy wydawców do wpisywania do tabeli
        String[] wyd = {"PWN", "PWE", "Czytelnik", "Amber", "HELION", "MIKOM"};

        // pierwszy numer wydawcy do wpisywania do tabeli: PWN ma numer 15, PWE ma 16, ...
        int beginKey = 15;
        int delCount =  0;
        try  {
            // przygotowanie instrukcji prekompilowanej
            stmt = con.prepareStatement("DELETE FROM Wydawca " +
                    "where name = ? or wydid = ?" );	// usunięcie z tabeli WYDAWCA rekordu o podanej nazwie wydawcy z tablicy wyd lub o podanym numerze wydawcy zaczynającym się od beginKey
            for (int i=0; i < wyd.length; i++)   {
                stmt.setString(1,wyd[i]);
                stmt.setInt(2,beginKey++);
                if (stmt.executeUpdate() == 1)
                    delCount++;
            }
            con.close();
        } catch(SQLException exc)  {
            System.out.println(exc);
        }finally {
            try {
                System.out.println("Do tabeli wyrzucono " + delCount + " rekordow");
                stmt.close();
                con.close();
            } catch (SQLException exc) {
                System.out.println(exc);
                System.exit(1);
            }
        }

    }
}
