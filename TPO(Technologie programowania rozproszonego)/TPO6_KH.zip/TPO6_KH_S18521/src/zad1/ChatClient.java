/**
 *
 *  @author Kunitskaya Hanna S18521
 *
 */

package zad1;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.*;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class ChatClient {

    private String id;
    private StringBuilder chatLog;
    private static final Charset charset = StandardCharsets.UTF_8;
    private SocketChannel connectSocketChannel;


    public ChatClient(String host, int port, String id) throws IOException {
        this.id = id;
        this.chatLog = new StringBuilder("=== " + id + " chat view\n");

        serverSetUp(host, port);
    }

    public void login() throws IOException {
        send("xx login " + id);
    }

    public void logout() throws IOException {
        send("xx logout " + id);
        chatLog.append(id).append(" logged out\n");
    }


    public void send(String message) throws IOException {
        ByteBuffer sendBuffer = ByteBuffer.allocateDirect(message.getBytes().length);
        ByteBuffer readBuffer = ByteBuffer.allocateDirect(1024);

            sendBuffer.put(charset.encode(message));
            sendBuffer.flip();

            connectSocketChannel.write(sendBuffer);
            connectSocketChannel.read(readBuffer);

            readBuffer.flip();
            CharBuffer charBuffer = charset.decode(readBuffer);
            chatLog.append(charBuffer.toString());

    }
    public String getChatView() {
        return chatLog.toString();
    }

    private void serverSetUp(String host, int port) throws IOException {

        connectSocketChannel = SocketChannel.open();
        connectSocketChannel.configureBlocking(false);
        connectSocketChannel.connect(new InetSocketAddress(host, port));

        while (!connectSocketChannel.finishConnect()) {  }

    }
}
