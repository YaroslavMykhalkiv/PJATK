package com.example.pro1prm

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.pro1prm.databinding.ListItemBinding
import com.example.pro1prm.databinding.PriorityElemBinding

class TaskPriorityViewHolder(val binding: PriorityElemBinding)
    : RecyclerView.ViewHolder(binding.root){

    var idPriority: String = "Usual"
        private set

    fun bind(priorityElem: String, isSelected: Boolean){
        idPriority = priorityElem
        binding.priorityElem.setText(priorityElem)
        binding.frameCard.visibility =
            if (isSelected) View.VISIBLE else View.INVISIBLE
    }
}

class TaskPrioritiesAdapter : RecyclerView.Adapter<TaskPriorityViewHolder>() {

    private val priorities = listOf("Low", "Usual", "High")
    private var selectedPosition: Int = 1
    var selectedIdPriority = "Usual"
    get() = priorities[selectedPosition]

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskPriorityViewHolder {
        val binding = PriorityElemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return TaskPriorityViewHolder(binding).also { vh ->
            binding.root.setOnClickListener{
                notifyItemChanged(selectedPosition)
                selectedPosition = vh.layoutPosition
                notifyItemChanged(selectedPosition)
            }
        }
    }

    fun setSelected(pos: String){
        selectedPosition = priorities.indexOf(pos)
    }

    override fun onBindViewHolder(holder: TaskPriorityViewHolder, position: Int) {
        holder.bind(priorities[position], position == selectedPosition)
    }

    override fun getItemCount(): Int = priorities.size

}