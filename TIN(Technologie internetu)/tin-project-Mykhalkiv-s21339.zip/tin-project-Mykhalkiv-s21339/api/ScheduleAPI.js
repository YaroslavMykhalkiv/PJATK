const ScheduleRepository = require ('../repository/mysql2/GrafikRepository');


exports.getSchedules = (req, res, next) => {
    ScheduleRepository.getSchedules()
        .then(schedules =>{
            res.status(200).json(schedules) ;

        })
        .catch(err=>{
            console.log(err);
        });
};

exports.getScheduleById = (req, res, next) => {
    const scheduleId = req.params.scheduleId;
    ScheduleRepository.getScheduleById(scheduleId)
        .then(schedule => {
            res.status(200).json(schedule) ;  
        });
}

exports.createSchedule = (req, res, next) => {
    
    ScheduleRepository.createSchedule(req.body)
        .then(newObj => {      
            res.status(201).json(newObj) ;
        })
        .catch(err => {

            if (!err.statusCode) {
                err.statusCode = 500;
            }
            next(err);
        });
}

exports.updateSchedule = (req, res, next) => {
    const scheduleId = req.params.scheduleId;
    ScheduleRepository.updateSchedule(scheduleId, req.body)
        .then(result => {
            res.status(200).json({message: 'Schedule updated', schedule: result});
        })
        .catch(err => {
            if(!err.statusCode) {
                err.statusCode = 500;
            }
            next(err);
        });
};


exports.deleteSchedule = (req, res, next) => {
    const scheduleId = req.params.scheduleId;
    ScheduleRepository.deleteSchedule(scheduleId)
        .then(result => {
            res.status(200).json({message: 'Schedule deleted', schedule: result});
        })
        .catch(err => {
            if(!err.statusCode) {
                err.statusCode = 500;
            }
            next(err);
        });
};