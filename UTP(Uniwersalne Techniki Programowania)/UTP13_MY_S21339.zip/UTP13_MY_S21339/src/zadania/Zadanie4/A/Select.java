package Zadanie4.A;

import java.sql.*;

public class Select {
    static public void main(String[] args) {
        new Select();
    }

    Select() {
        Connection con = null;
        String url = "jdbc:derby:C:\\drb\\ksidb";
        try {
            con = DriverManager.getConnection(url);
        } catch (Exception exc) {
            System.out.println(exc);
            System.exit(1);
        }
        String sel = "SELECT name ,  tytul, rok, cena " +
                    "from autor " +
                    "join pozycje on pozycje.AUTID = autor.AUTID " +
                    "where rok > 2000 and cena > 30";
        try  {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sel);
            while (rs.next())  {
                String nawisko = rs.getString("name");
                String tytul = rs.getString(2);
                int rok = rs.getInt("rok");
                double cena = rs.getDouble(4);
                System.out.println("Autor: " + nawisko + " , tutyl: " + tytul + ", rok wydania : " + rok + ", cena: " + cena);
            }
            stmt.close();
            con.close();
        } catch (SQLException exc)  {
            System.out.println(exc.getMessage());
        }

    }
}
