/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


public interface Mapper<M,Y> { // Uwaga: interfejs musi być sparametrtyzowany
    public Y map (M y);
}
