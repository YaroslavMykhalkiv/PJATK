function validateForm(){
    const firstNameInput = document.getElementById('firstName');
    const lastNameInput = document.getElementById('lastName');
    const salaryInput = document.getElementById('salary');

    const errorFirstName = document.getElementById('errorFirstName');
    const errorLastName = document.getElementById('errorLastname');
    const errorSalary = document.getElementById('errorsalary');
    const errorSummary = document.getElementById('errorsSummary');
    let valid = true;
     resetErrors([firstNameInput,lastNameInput,salaryInput], [errorFirstName,errorLastName,errorSalary],errorSummary);

    if(!checkRequired(firstNameInput.value)){
        valid = false;
        firstNameInput.classList.add("error-input");
        errorFirstName.innerText = "Pole jes wymagane";
    
    }else if(!checkTextLenghtRange(firstNameInput.value,2,60)){
        valid = false;
        firstNameInput.classList.add("error-input");
        errorFirstName.innerText = "Pole powinno zawierac od 2 do 60 znakow";
    
    }

    if(!checkRequired(lastNameInput.value)){
        valid = false;
        lastNameInput.classList.add("error-input");
        errorLastName.innerText = "Pole jes wymagane";
    
    } else if(!checkTextLenghtRange(lastNameInput.value,2,60)){
        valid = false;
        lastNameInput.classList.add("error-input");
        errorLastName.innerText = "Pole powinno zawierac od 2 do 60 znakow";
    
    }

    if(!checkRequired(salaryInput.value)){
        valid = false;
        salaryInput.classList.add("error-input");
        errorSalary.innerText = "Pole jes wymagane";
    
    } else if(!checkNumberRange(salaryInput.value,1000,10000)){
        valid = false;
        salaryInput.classList.add("error-input");
        errorSalary.innerText = "Pole powinno byc w przedziale od 1000 do 10000";
    
    }



    if(!valid){
        errorSummary.innerText = "Formularz zawiera bledy";
    }
    return valid;
}

