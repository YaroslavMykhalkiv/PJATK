const express = require('express');
const router = express.Router();

const grafikController = require('../controllers/grafikController');

router.get('/', grafikController.showGrafikList);
router.get('/add', grafikController.showAddScheduleForm);
router.get('/edit/:grafikdId', grafikController.showScheduleForm);
router.get('/details/:grafikdId', grafikController.showScheduleDetails);
router.post('/add', grafikController.addSchedule);
router.post('/edit', grafikController.updateSchedule);
router.get('/delete/:grafikdId', grafikController.deleteSchedule);

module.exports = router;