const Joi = require('joi');

const errMessages = (errors) => {
    errors.forEach(err => {
        switch(err.code) {
            case "number.base":
                err.message = "Pole jest wymagane";
                break;
            default:
                break;
        }
    });
    return errors;
}


const scheduleSchema = Joi.object({
    _idSchedule: Joi.number()
            .optional()
            .allow(""),
    room_id: Joi.number()
            .required()
            .error(errMessages),
    emp_id: Joi.number()
            .required()
            .error(errMessages),
    time_start: Joi.string()
            .required()
            .error(errMessages),
    time_end: Joi.string()
            .required()
            .error(errMessages),
    done: Joi.boolean()
            .optional()
            .allow("")
});

module.exports = scheduleSchema;

