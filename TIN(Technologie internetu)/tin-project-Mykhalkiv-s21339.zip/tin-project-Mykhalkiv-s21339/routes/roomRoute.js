const express = require('express');
const router = express.Router();

const roomController = require('../controllers/roomController');

router.get('/', roomController.showRoomList);
router.get('/add', roomController.showAddRoomForm);
router.get('/edit/:roomId', roomController.showRoomForm);
router.get('/details/:roomId', roomController.showRoomDetails);
router.post('/add', roomController.addRoom);
router.post('/edit', roomController.updateRoom);
router.get('/delete/:roomId', roomController.deleteRoom);
module.exports = router;