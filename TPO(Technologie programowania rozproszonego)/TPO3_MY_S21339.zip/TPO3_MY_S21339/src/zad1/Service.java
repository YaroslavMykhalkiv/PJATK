/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Map;
import java.util.Scanner;



public class Service {
    String kraj;
    String codeRateKraj;

    public Service(String kraj){
        this.kraj = kraj;
        codeRateKraj = getCodeFromCountry(kraj);
    }

    public static String getCodeFromCountry(String country){
        Scanner scanFile;
        String code ="";
        try {
            scanFile = new Scanner(new File("codeCountry.txt"));
            while (scanFile.hasNextLine()){
                code = scanFile.nextLine();
                String[] tab = code.split("\t");
                if (tab[0].contains(country.toUpperCase())){
                    code = tab[2];
                    break;
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
       // System.out.println(code);
            return code;
    }




    public String getWeather(String miasto){
        String resultJson = "";
        String result = "";
        try {
            URL url = new URL("http://api.openweathermap.org/data/2.5/weather?q=" + miasto
                    + "&appid=b6367bd40dfb51859897db09261f4e1c&units=metric");
            URLConnection connection = url.openConnection();
            Scanner readUrl = new Scanner((InputStream) url.getContent());
            while (readUrl.hasNext()){
                resultJson += readUrl.nextLine() ;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return resultJson;
    }

    public Double getRateFor(String kod_waluty){
        String resultJson = "";
        double rates = 0;
        try {
            URL url = new URL("https://api.exchangerate.host/latest?base="+kod_waluty+"&symbols="+codeRateKraj);
            URLConnection connection = url.openConnection();
            Scanner readUrl = new Scanner((InputStream) url.getContent());
            while (readUrl.hasNext()){
                resultJson += readUrl.nextLine() ;
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
        JSONObject json = new JSONObject(resultJson);
//        System.out.print(codeRateKraj + " in " + kod_waluty + " = ");
        rates = json.getJSONObject("rates").getDouble(codeRateKraj);
        return rates;
    }

    public Double getNBPRate(){

        char tables = 'a';

        double rates = 0;
        try {

            for (int i = 0; i < 2; i++) {
                String resultJson = "";
                URL url1 = new URL("http://api.nbp.pl/api/exchangerates/tables/"+tables+"/");
                URLConnection connection = url1.openConnection();
                Scanner readUrl = new Scanner((InputStream) url1.getContent());
                String row;
                while (readUrl.hasNextLine()){
                    resultJson += readUrl.nextLine();
                }
                JSONArray json = new JSONArray(resultJson);
                JSONObject jsonObject = json.getJSONObject(0);
                if (rates==0) {
                   // System.out.println(resultJson);
                    for (int j = 0; j < jsonObject.getJSONArray("rates").length(); j++) {
                        JSONObject object = (JSONObject) jsonObject.getJSONArray("rates").get(j);
                        if (object.get("code").equals(codeRateKraj)) {
                            rates = object.getDouble("mid");
                            break;
                        }
                    }
                }
                tables = 'b';
            }




        } catch (IOException e) {
            e.printStackTrace();
        }


        return rates;
    }
}
