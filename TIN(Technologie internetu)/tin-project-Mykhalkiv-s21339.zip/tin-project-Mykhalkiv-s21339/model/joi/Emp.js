const Joi = require('joi');

const errMessages = (errors) => {
    errors.forEach(err => {
        switch(err.code) {
            case "string.empty":
                err.message = "Pole jest wymagane";
                break;
            case "string.min":
                err.message = `Pole powinno zawierac co najmniej ${err.local.limit} znaki`;
                break;
            case "string.max":
                err.message = `Pole powinno zawierac co najwyzej ${err.local.limit} znaki`;
                break;
            case "number.min":
                err.message = `Pole powinno byc w przedziale od 1000 do 10000`;
                break;
            case "number.max":
                err.message = `Pole powinno byc w przedziale od 1000 do 10000`;
                break;
            case "number.base":
                err.message = "Pole jest wymagane";
                break;
            default:
                break;
        }
        console.log(err.code);
    });
    return errors;
}


const empSchema = Joi.object({
    _idEmp: Joi.number()
            .optional()
            .allow(""),
        firstName: Joi.string()
                .min(2)
                .max(60)
                .required()
                .error(errMessages),
        lastName:Joi.string()
                .min(2)
                .max(60)
                .required()
                .error(errMessages),
        salary: Joi.number()
                .min(1000)
                .max(10000)
                .required()
                .error(errMessages)

});

module.exports = empSchema;

