package zad2;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.util.ArrayList;
import java.util.List;

public class Futil extends SimpleFileVisitor {
    public static void processDir(String dirName, String resultFileName) {
        List<String> ready = new ArrayList<>();
        try {
            Files.walk(Path.of(dirName)).filter(Files::isRegularFile).forEach(file -> {
                try {
                    File fileDir = new File(String.valueOf(file));
                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(
                                    new FileInputStream(fileDir), "Cp1250"));
                    String str;
                    while ((str = in.readLine()) != null) {
                        ready.add(str);
                    }
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            Files.write(Path.of(resultFileName), ready,Charset.forName("UTF-8"));
        } catch (IOException e) {
            e.getStackTrace();
        }
    }

}
