package com.example.pro1prm

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pro1prm.databinding.FragmentListBinding
import com.example.pro1prm.databinding.ListItemBinding

class TaskViewHolder(val binding: ListItemBinding)
    : RecyclerView.ViewHolder(binding.root){
        @RequiresApi(Build.VERSION_CODES.O)
        fun bind(task: Task){
            binding.name.text = task.name
            binding.priority.text = task.priority
            binding.timeLeft.text = task.timeLeft
            binding.deadline.text = task.deadline.toString()
            binding.percent.text = task.percent.toString()
        }
    }

class TasksAdapter(val activity: FragmentActivity?) : RecyclerView.Adapter<TaskViewHolder>() {

    private val data = mutableListOf<Task>()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ListItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )


       return TaskViewHolder(binding)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(data[position])

        holder.binding.cardView.setOnClickListener{
            val det = DetailsFragment()
            var bundle = Bundle()
            bundle.putString("Name",holder.binding.name.text.toString())
            bundle.putString("Deadline",holder.binding.deadline.text.toString())
            bundle.putString("Priority",holder.binding.priority.text.toString())
            bundle.putInt("DaysLeft",holder.binding.timeLeft.text.toString().toInt())
            bundle.putInt("Percent",holder.binding.percent.text.toString().toInt())
            det.arguments = bundle
            DataSource.tasks.remove(data[position])
            (activity as? Navigable)?.navigate(det)

        }
        holder.binding.cardView.setOnLongClickListener {
            val builder = AlertDialog.Builder(it.context)
            builder.setMessage("Are you want to finish this task?")
            builder.setPositiveButton(android.R.string.yes) { dialog, which ->
                DataSource.tasks.remove(data[position])
                replace(DataSource.clearSortedList())
            }
            builder.show()
            true
        }
    }

    override fun getItemCount(): Int = data.size

    @RequiresApi(Build.VERSION_CODES.O)
    fun replace(newData: List<Task>){
        data.clear()
        data.addAll(newData)
        notifyDataSetChanged()

    }
}