package zad1.B;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Buffer {
    BlockingQueue<Integer> drop;
    int size;
    final Lock locker ;
    final Condition empty ;
    final Condition full ;

    public Buffer(int size){
        this.size = size;
        drop = new ArrayBlockingQueue<Integer>(size, true);
        locker = new ReentrantLock();
        full = locker.newCondition();
        empty = locker.newCondition();
    }

    public void get(){
        locker.lock();
        try {
            while (isEmpty()) {
                System.out.println("Consumer wait");
                full.await();
            }
            System.out.println("consumer " + drop.take() + ", size: " + drop.size());
            empty.signal();
        } catch (InterruptedException e) { }
        finally {
            locker.unlock();
        }
    }

    public int put(int produkt){
        locker.lock();
        try {
            while (drop.size() >= size) {
                System.out.println("Producer wait");
                empty.await();
            }
            drop.put(produkt);
            System.out.println("Producer " + produkt + ", size: " + drop.size());
            full.signal();
            return produkt;
        } catch (InterruptedException e) {
            return 0;
        }finally {
            locker.unlock();
        }

    }

    public boolean isFull(){
        return drop.size() == size;
    }

    public boolean isEmpty(){
        return drop.size() == 0;
    }
}
