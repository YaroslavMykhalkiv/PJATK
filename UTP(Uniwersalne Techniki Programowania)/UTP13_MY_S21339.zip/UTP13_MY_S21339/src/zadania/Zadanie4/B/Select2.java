package Zadanie4.B;

import java.sql.*;

public class Select2 {
    static public void main(String[] args) {
        new Select2();
    }

    Select2() {
        Connection con = null;
        String url = "jdbc:derby:C:\\drb\\ksidb";
        try {
            con = DriverManager.getConnection(url);
        } catch (Exception exc) {
            System.out.println(exc);
            System.exit(1);
        }
//        String sel = "SELECT name ,  tytul, rok, cena " +
//                    "from autor " +
//                    "join pozycje on pozycje.AUTID = autor.AUTID " +
//                    "where rok > 2000 and cena > 30";

        String sel = "SELECT name ,  tytul, rok, cena " +
                "from autor " +
                "join pozycje on pozycje.AUTID = autor.AUTID ";
        try  {
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery(sel);
            ResultSetMetaData rsmd = rs.getMetaData();
            int cc = rsmd.getColumnCount();
            for (int i = 1; i <= cc; i++)
                System.out.print(rsmd.getColumnLabel(i) + "     ");

            System.out.println("\n------------------------------ przewijanie do góry");
            rs.afterLast();
            while (rs.previous())  {
                for (int i = 1; i <= cc; i++)
                    System.out.print(rs.getString(rsmd.getColumnName(i)) + "  || ");
                System.out.println("");
            }

            System.out.println("\n----------------------------- pozycjonowanie abs.");
            int[] poz =  { 3, 7, 9  };
            for (int p = 0; p < poz.length; p++)  {
                System.out.print("[ " + poz[p] + " ] ");
                rs.absolute(poz[p]);
                for (int i = 1; i <= cc; i++) System.out.print(rs.getString(i) + ", ");
                System.out.println("");
            }
            stmt.close();
            con.close();
        } catch (SQLException exc)  {
            System.out.println(exc.getMessage());
        }

    }
}
