package zad1;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;

public class Futil extends SimpleFileVisitor {


    public static void processDir(String dirname, String filename){
        List<String> ready = new ArrayList<>();
        try {
            Files.walkFileTree(Path.of(dirname), new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                        throws IOException {
                    if (attrs.isRegularFile()) {
                        System.out.println("visitFile: " + file);
                        File fileDir = new File(String.valueOf(file));
                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(
                                        new FileInputStream(fileDir), "Cp1250"));
                        String str;
                        while ((str = in.readLine()) != null) {
                            ready.add(str);
                        }
                        in.close();
                    }
                    return FileVisitResult.CONTINUE;
                }
            });
            Files.write(Path.of(filename),ready,Charset.forName("UTF-8"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



}
