package zad3;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class AccountChange implements PropertyChangeListener {

    @Override
    public void propertyChange(PropertyChangeEvent propertyChangeEvent) {

        if ((double) propertyChangeEvent.getNewValue() < 0)
        System.out.println(propertyChangeEvent.getPropertyName() + ": Value changed from " + propertyChangeEvent.getOldValue() + " to " + propertyChangeEvent.getNewValue() + ", balance < 0!");
        else
            System.out.println(propertyChangeEvent.getPropertyName() + ": Value changed from " + propertyChangeEvent.getOldValue() + " to " + propertyChangeEvent.getNewValue());

    }
}
