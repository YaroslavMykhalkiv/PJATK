package zad1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Main {
    static JPanel jp = new JPanel();
    static JFrame jf = new JFrame();
    static ArrayList<MyThread> lista = new ArrayList<MyThread>();
    public static void main(String[] args) {
        try {
            JButton jb1 = new JButton("Create");
            JButton stop = new JButton("Stop");
            JTextArea tx = new JTextArea(25,25);
            tx.validate();
            tx.setEditable(false);
            MyThread.tx = tx;
            stop.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    for (MyThread t : lista){
                        t.end();
                        t.stop();
                    }
                    stop.setEnabled(false);
                    jb1.setEnabled(false);
                }
            });
            jb1.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    JButton but = new JButton("T" + MyThread.index);
                    MyThread m = new MyThread(but);
                    lista.add(m);
                    but.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            if (but.getText().startsWith("S")) {
                                but.setText("Continue T" + m.cur);
                                m.setStatus(false);
                            } else if (but.getText().startsWith("C")) {
                                but.setText("Suspend T" + m.cur);
                                m.setStatus(true);
                            }
                            if (but.getText().startsWith("T")) {
                                but.setText("Suspend T" + m.cur);
                                m.start();
                            }
                            SwingUtilities.updateComponentTreeUI(jf);
                        }
                    });
                    jp.add(but);
                    SwingUtilities.updateComponentTreeUI(jf);
                }
            });
            jf.setSize(300, 600);
            JScrollPane jsp = new JScrollPane(tx);
            jp.setLayout(new FlowLayout());
            jsp.createVerticalScrollBar();
            jf.setVisible(true);
            jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            jp.add(stop);
            jp.add(jb1);
            jp.add(jsp,BorderLayout.CENTER);
            jf.getContentPane().add(jp);
        }catch (Exception e){}

    }
}
