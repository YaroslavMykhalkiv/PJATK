/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;

public class Client {
    SocketChannel socketChannel;
    String host;
    int port;
    String id;

    final int sizeBB = 1024;
    private final Charset ISO = Charset.forName("ISO-8859-2");
    private final ByteBuffer BB = ByteBuffer.allocate(sizeBB);

    public Client(String host, int port, String id)
    {
        this.host = host;
        this.port = port;
        this.id = id;
    }

    public void connect()
    {
        try
        {
            socketChannel = SocketChannel.open();
            socketChannel.configureBlocking(false);
            socketChannel.connect(new InetSocketAddress(host, port));
            while(!socketChannel.finishConnect()) { }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public String send(String req)
    {
        try
        {
            ByteBuffer writeBuf = ISO.encode(req);
            socketChannel.write(writeBuf);
            int readByte;

            while((readByte = socketChannel.read(BB)) != 1)
            {
                BB.clear();
                if(readByte != 0) {
                    BB.flip();
                    return new String(BB.array(), 0, readByte);
                }
            }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        return "";
    }
}
