package zad1;

import javax.jms.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.swing.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Hashtable;

public class JMSChat {

    TopicConnection connectionToServer;
    TopicSession sessionServer;
    TopicPublisher publisher;
    BufferedReader bufRed;
    TopicSubscriber subscriber;
    JTextArea chatView;
    String user;
    JScrollPane scrollPane;


    public JMSChat(JTextArea chatView, String user, JScrollPane scrollPane) {
        this.chatView = chatView;
        this.user = user;
        this.scrollPane = scrollPane;
        try {
            Hashtable<String, String> properties = new Hashtable<>();
            properties.put(Context.INITIAL_CONTEXT_FACTORY, "org.exolab.jms.jndi.InitialContextFactory");
            properties.put(Context.PROVIDER_URL, "tcp://localhost:3035/");

            Context context = new InitialContext(properties);
            TopicConnectionFactory connectionFactory = (TopicConnectionFactory) context.lookup("ConnectionFactory");

            connectionToServer = connectionFactory.createTopicConnection();

            sessionServer = connectionToServer.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topic = (Topic) context.lookup("topic1");

            publisher = sessionServer.createPublisher(topic);
            subscriber = sessionServer.createSubscriber(topic);

            bufRed = new BufferedReader(new InputStreamReader(System.in));

            connectionToServer.start();
        } catch (NamingException | JMSException e) {
            e.printStackTrace();
        }
    }

    public void sendMessage(String message) {
        try {
            publisher.publish(sessionServer.createTextMessage( message));
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }

    public void getMessage() throws JMSException {
        subscriber.setMessageListener(arg0 -> {
            TextMessage msg = (TextMessage) arg0;
            if (arg0.toString().startsWith(user))
                chatView.append("\n" + "YOU:" + msg.toString().substring(user.length()));
            else
                chatView.append("\n" + msg);
            scrollPane.getVerticalScrollBar().setValue(chatView.getHeight());

        });
    }

}