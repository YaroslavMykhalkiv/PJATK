package com.example.pro1prm

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.location.Address
import android.location.Geocoder
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.fragment.app.Fragment
import com.example.pro1prm.DataSource.meals
import com.example.pro1prm.databinding.FragmentEditAddBinding
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.location.*
import java.util.*


class EditAddFragment(val type: Type) : Fragment() {

    enum class Type{
         Add, Edit
    }

    private lateinit var binding: FragmentEditAddBinding
    var mFusedLocationClient: FusedLocationProviderClient? = null

    val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        if (type == Type.Add) {
            startActivityForResult(cameraIntent, 42)
            getLastKnownLocation()
        }
        super.onCreate(savedInstanceState)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return FragmentEditAddBinding.inflate(inflater, container, false).also {
            binding = it
        }.root
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.textAction.setText("Adding new meal")

        if (type == Type.Edit){
            binding.textAction.setText("Edditing meal")
            binding.btnDelete.visibility = View.VISIBLE
            binding.cardBtnDelete.visibility = View.VISIBLE
            binding.btnDelete.setOnClickListener{
                meals.removeAt(arguments?.getInt("Id")!!)
                (activity as? Navigable)?.navigate(Navigable.Destination.List)
            }
            val bundle = arguments
            val meal = meals.get(bundle?.getInt("Id")!!)

            binding.mealName.setText(meal.name)
            binding.mealAdres.setText(meal.adres)
            binding.pictureIcon.setImageBitmap(meal.picId)
            binding.extraInfo.setText(meal.extra)
        }
        binding.btnPicture.setOnClickListener{
            startActivityForResult(cameraIntent, 42)
        }
        binding.extraInfo.setBackgroundResource(android.R.color.transparent)

        binding.save.setOnClickListener{
            if (valid()) {
                if (type == Type.Edit)
                    meals.removeAt(arguments?.getInt("Id")!!)
                val newMeal = Meal(
                    binding.mealName.text.toString(),
                    binding.mealAdres.text.toString(),
                    binding.pictureIcon.drawable.toBitmap(),
                    binding.extraInfo.text.toString()
                )
                meals.add(newMeal)
                (activity as? Navigable)?.navigate(Navigable.Destination.List)
            }
        }

        binding.btnLocation.setOnClickListener{
            getLastKnownLocation()
        }
    }

    fun getLastKnownLocation() {
        askLocation()
        mFusedLocationClient =
            activity?.let { LocationServices.getFusedLocationProviderClient(it) };
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext())
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location->
                if (location != null) {
                    binding.mealAdres.setText(getCompleteAddressString(location.latitude, location.longitude))
                }
            }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val photo = data?.extras?.get("data")
        var bitMap = photo as Bitmap
        bitMap = Bitmap.createScaledBitmap(bitMap, bitMap.width*2, bitMap.height*2, true)
        binding.pictureIcon.setImageBitmap(bitMap);
    }

    private fun getCompleteAddressString(LATITUDE: Double, LONGITUDE: Double): String? {
        var strAdd = ""
        val geocoder = Geocoder(this.context, Locale.getDefault())
        try {
            val addresses: List<Address>? = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1)
            if (addresses != null) {
                val returnedAddress: Address = addresses[0]
                strAdd = "ul. " + returnedAddress.thoroughfare + " " + returnedAddress.subAdminArea + " " + returnedAddress.countryName
            } else {
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return strAdd
    }

    private fun valid(): Boolean{
        var isValid = true
        normalize()
        if(binding.mealName.text.isBlank()){
            binding.nameLabel.setTextColor(Color.RED)
            binding.nameLabel.setTypeface(null, Typeface.BOLD)
            isValid = false
        }
        if(binding.mealAdres.text.isBlank()){
            binding.labelAdres.setTextColor(Color.RED)
            binding.labelAdres.setTypeface(null, Typeface.BOLD)
            isValid = false
            askLocation()
        }
        return isValid
    }

    private fun normalize(){
        binding.nameLabel.setTextColor(binding.pictureLabel.currentTextColor)
        binding.nameLabel.setTypeface(null, Typeface.NORMAL)
        binding.labelAdres.setTextColor(binding.pictureLabel.currentTextColor)
        binding.labelAdres.setTypeface(null, Typeface.NORMAL)
    }

    private fun askLocation(){
        var interval = 1000 * 60 * 1
        var fastestInterval = 1000 * 50

        try {
            var googleApiClient =  GoogleApiClient.Builder( requireContext()).addApi( LocationServices.API ).build();

            googleApiClient.connect();

            var locationRequest = LocationRequest.create()
                .setPriority( LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY )
                .setInterval( interval.toLong() )
                .setFastestInterval( fastestInterval.toLong() );

            var locationSettingsRequestBuilder = LocationSettingsRequest.Builder()
                .addLocationRequest( locationRequest );

            locationSettingsRequestBuilder.setAlwaysShow( false );


            var locationSettingsResult = LocationServices.SettingsApi.checkLocationSettings(
                    googleApiClient, locationSettingsRequestBuilder.build() );
            locationSettingsResult.addStatusListener {
                if (it.statusCode == LocationSettingsStatusCodes.RESOLUTION_REQUIRED)
                    activity?.let { it1 -> it.startResolutionForResult(it1, 0 ) };
            }
        } catch( exception : Exception  ) {
            // Log exception
        }

    }
}