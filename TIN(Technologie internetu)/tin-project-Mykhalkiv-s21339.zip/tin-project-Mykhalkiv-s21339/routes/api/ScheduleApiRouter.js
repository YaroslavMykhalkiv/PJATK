const express = require('express');
const router = express.Router();

const scheduleApiController = require('../../api/ScheduleAPI');

router.get('/', scheduleApiController.getSchedules);
router.get('/:scheduleId', scheduleApiController.getScheduleById);
router.post('/', scheduleApiController.createSchedule);
router.put('/:scheduleId', scheduleApiController.updateSchedule);
router.delete('/:scheduleId', scheduleApiController.deleteSchedule);

module.exports = router;