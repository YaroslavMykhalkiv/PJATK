package com.example.pro1prm

import android.graphics.Bitmap
import android.media.Image
import android.widget.ImageView
import androidx.annotation.DrawableRes
import java.io.Serializable
import java.time.LocalDate

data class Meal(
    val name: String,
    val adres: String,
    val picId: Bitmap,
    val extra: String
)
