package com.example.pro1prm

import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.pro1prm.databinding.FragmentEditAddBinding
import java.time.LocalDate
import java.time.temporal.ChronoField

class EditAddFragment(val type: Type) : Fragment() {

    enum class Type{
         Add, Edit
    }

    private lateinit var binding: FragmentEditAddBinding

    private lateinit var adapter: TaskPrioritiesAdapter

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return FragmentEditAddBinding.inflate(inflater, container, false).also {
            binding = it
            binding.taskDeadline.setText(LocalDate.now().toString())
        }.root
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = TaskPrioritiesAdapter()


        if (type == Type.Edit){
            val bundle = arguments
            val name = bundle?.get("Name").toString()
            val percent = bundle?.get("Percent").toString()
            val priority = bundle?.get("Priority").toString()
            val deadline = bundle?.get("Deadline").toString()
            val daysLeft = bundle?.get("DaysLeft").toString()
            binding.taskName.setText(name)
            binding.taskPercent.setText(percent)
            binding.taskDeadline.setText(deadline)
            adapter.setSelected(priority)
        }

        binding.listPriority.apply {
            adapter = this@EditAddFragment.adapter
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        }

        binding.save.setOnClickListener{
            val newTask = Task(
                binding.taskName.text.toString(),
                adapter.selectedIdPriority,
                (LocalDate.parse(binding.taskDeadline.text.toString()).getLong(ChronoField.DAY_OF_YEAR) - DataSource.curDate).toString(),
                binding.taskPercent.text.toString().toInt(),
                LocalDate.parse(binding.taskDeadline.text.toString())
            )
            DataSource.tasks.add(newTask)
            (activity as? Navigable)?.navigate(Navigable.Destination.List)
        }
    }



}