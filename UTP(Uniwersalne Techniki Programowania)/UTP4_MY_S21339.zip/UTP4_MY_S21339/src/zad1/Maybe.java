package zad1;

import java.util.NoSuchElementException;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Maybe<T> {
    T t;


     Maybe(T t){
            this.t = t;
    }

     static <T>Maybe<T> of(T t){
        Maybe<T> mb = new Maybe(t);
        return mb;
    }

     void ifPresent(Consumer<T> cons){
        if (t != null)
        cons.accept(this.t);
    }

     <R>Maybe<R> map(Function<T,R> func){

        if (isPresent())
            return  new Maybe<R>(func.apply(t));
        else
            return  new Maybe<R>(null);

    }

     T get(){
        if (!isPresent())
            throw new NoSuchElementException(" maybe is empty");
        return t;
    }

     boolean isPresent(){
        return t != null ;
    }

     T orElse(T defVal){
        if (isPresent())
            return t;
        else
            return defVal;
    }

    Maybe<T> filter(Predicate<T> pred){
         if (!isPresent())
             if (pred.test(t))
                return this;
             else
                 return new Maybe<T>(null);

         else
             return this;
    }


    public String toString(){
        if (isPresent())
            return "Maybe has value " + t;
        else
            return "Maybe is empty";
    }
}
