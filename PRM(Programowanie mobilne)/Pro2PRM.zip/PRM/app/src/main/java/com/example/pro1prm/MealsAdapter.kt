package com.example.pro1prm

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.core.graphics.drawable.toBitmap
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.pro1prm.DataSource.meals
import com.example.pro1prm.databinding.ListItemBinding

class MealViewHolder(val binding: ListItemBinding)
    : RecyclerView.ViewHolder(binding.root){
        @SuppressLint("NewApi")
        fun bind(meal: Meal){
            binding.name.text = meal.name
            binding.adres.text = meal.adres
            binding.picture.setImageBitmap(meal.picId)
            binding.extra.width = binding.picture.width - 10
            binding.extra.text = meal.extra
            binding.extra.maxWidth = binding.picture.width - 10
        }
    }

class MealsAdapter(val activity: FragmentActivity?) : RecyclerView.Adapter<MealViewHolder>() {

    private val data = mutableListOf<Meal>()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MealViewHolder {
        val binding = ListItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )


       return MealViewHolder(binding)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onBindViewHolder(holder: MealViewHolder, position: Int) {
        holder.bind(data[position])

        holder.binding.cardView.setOnClickListener{
            val det = EditAddFragment(EditAddFragment.Type.Edit)
            var bundle = Bundle()
            bundle.putInt("Id", position)
            det.arguments = bundle
            (activity as? Navigable)?.navigate(det)

        }
        holder.binding.cardView.setOnLongClickListener {
            val builder = AlertDialog.Builder(it.context)
            builder.setMessage("Do you want to remove this meal?")
            builder.setPositiveButton(android.R.string.yes) { dialog, which ->
                meals.remove(data[position])
                replace(meals)
            }
            builder.show()
            true
        }
    }

    override fun getItemCount(): Int = data.size

    @RequiresApi(Build.VERSION_CODES.O)
    fun replace(newData: List<Meal>){
        data.clear()
        data.addAll(newData)
        notifyDataSetChanged()

    }
}