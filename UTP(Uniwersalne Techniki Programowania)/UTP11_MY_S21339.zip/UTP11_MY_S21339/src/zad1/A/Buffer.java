package zad1.A;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Buffer {
    List<Integer> tasma = new ArrayList<>();
    int size;
    final Lock locker ;
    final Condition empty ;
    final Condition full ;

    public Buffer(int size){
        this.size = size;
        locker = new ReentrantLock();
        full = locker.newCondition();
        empty = locker.newCondition();
    }

    public void get(){
        locker.lock();
        try {
            while (isEmpty()) {
                System.out.println("Consumer wait");
                full.await();
            }
            System.out.println("consumer " + tasma.remove(tasma.size()-1) + ", size: " + tasma.size());
            empty.signal();
        } catch (InterruptedException e) { }
        finally {
            locker.unlock();
        }
    }

    public int put(int produkt){
        locker.lock();
        try {
            while (tasma.size() >= size) {
                System.out.println("Producer wait");
                empty.await();
            }
            tasma.add(0,produkt);
            System.out.println("Producer " + produkt + ", size: " + tasma.size());
            full.signal();
            return produkt;
        } catch (InterruptedException e) {
            return 0;
        }finally {
            locker.unlock();
        }

    }

    public boolean isFull(){
        return tasma.size() == size;
    }

    public boolean isEmpty(){
        return tasma.size() == 0;
    }
}
