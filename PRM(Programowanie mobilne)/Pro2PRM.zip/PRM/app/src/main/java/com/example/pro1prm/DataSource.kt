package com.example.pro1prm

import android.media.Image
import android.os.Build
import android.widget.ImageView
import androidx.annotation.RequiresApi

object DataSource{

    @RequiresApi(Build.VERSION_CODES.O)
    var meals = mutableListOf<Meal>(
//        Meal(
//            "dfasdfafdffdasdfafsdfaasdfasfasffdfasdfasdfasfasdfasfsdfasdfafasdfasdfasdfadfafasdfdfasdfafdffdasdfafsdfaasdfasfasffdfasdfasdfasfasdfasfsdfasdfafasdfasdfasdfadfafasdfdfasdfafdffdasdfafsdfaasdfasfasffdfasdfasdfasfasdfasfsdfasdfafasdfasdfasdfadfafasdf",
//            "Pawlowska",
//
//        )
    )
}