function validateForm(){
    const numberInput = document.getElementById('number');
    const pietroInput = document.getElementById('pietro');
    const Ilosc_ludziInput = document.getElementById('Ilosc_ludzi');

    const errornumberInput = document.getElementById('errorNumber');
    const errorpietroInput = document.getElementById('errorPietro');
    const errorIlosc_ludziInput = document.getElementById('errorIlosc');
    const errorSummary = document.getElementById('errorsSummary');
    let valid = true;
    resetErrors([numberInput,pietroInput,Ilosc_ludziInput], [errornumberInput,errorpietroInput,errorIlosc_ludziInput],errorSummary);

    if(!checkRequired(numberInput.value)){
        valid = false;
        numberInput.classList.add("error-input");
        errornumberInput.innerText = "Pole jes wymagane";
    
    }else if(!checkNumberRange(numberInput.value,1,99)){
        valid = false;
        numberInput.classList.add("error-input");
        errornumberInput.innerText = "Pole powinno byc w przedziale od 1 do 99";
    
    }

    if(!checkRequired(pietroInput.value)){
        valid = false;
        pietroInput.classList.add("error-input");
        errorpietroInput.innerText = "Pole jes wymagane";
    
    } else if(!checkNumberRange(pietroInput.value,0,2)){
        valid = false;
        pietroInput.classList.add("error-input");
        errorpietroInput.innerText = "Pole powinno byc w przedziale od 0 do 2";
    
    }

    if(!checkRequired(Ilosc_ludziInput.value)){
        valid = false;
        Ilosc_ludziInput.classList.add("error-input");
        errorIlosc_ludziInput.innerText = "Pole jes wymagane";
    
    } else if(!checkNumberRange(Ilosc_ludziInput.value,1,4)){
        valid = false;
        Ilosc_ludziInput.classList.add("error-input");
        errorIlosc_ludziInput.innerText = "Pole powinno byc w przedziale od 1 do 4";
    
    }



    if(!valid){
        errorSummary.innerText = "Formularz zawiera bledy";
    }
    return valid;
}

