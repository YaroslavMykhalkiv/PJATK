/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import java.util.ArrayList;

public class Purchase {
        String index;
        String nazwisko;
        String produkt;
        double cena;
        double ilosc;

        public Purchase(String index,String nazwisko,String produkt,double cena,double ilosc){
            this.index = index;
            this.nazwisko = nazwisko;
            this.produkt = produkt;
            this.cena = cena;
            this.ilosc = ilosc;
        }

        public String toString(){
            return index + ";" + nazwisko + ";" + produkt + ";" + cena + ";" + ilosc;
        }

        public String kosztyNapis(){
            return "(koszt: " + (cena*ilosc) + ")";
        }

        public double koszty(){
            return (cena*ilosc);
        }

        public int numerIndeksu(){
            boolean isTrue = false;
            String number = "";
            for (int i = 1; i < index.length(); i++) {
                if (index.charAt(i) != '0' || isTrue == true){
                    isTrue = true;
                    number += index.charAt(i);
                }
            }
            return Integer.parseInt(number);
        }
}
