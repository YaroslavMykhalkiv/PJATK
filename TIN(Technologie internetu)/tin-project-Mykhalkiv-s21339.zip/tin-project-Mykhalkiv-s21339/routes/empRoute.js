const express = require('express');
const router = express.Router();

const empController = require('../controllers/empController');

router.get('/', empController.showEmpList);
router.get('/add', empController.showAddEmpForm);
router.get('/edit/:empId', empController.showEmpForm);
router.get('/details/:empId', empController.showEmpDetails);
router.post('/add', empController.addEmp);
router.post('/edit', empController.updateEmp);
router.get('/delete/:empId', empController.deleteEmp);
module.exports = router;