const EmployeeRepository = require ('../repository/mysql2/EmpRepository');


exports.getEmps = (req, res, next) => {
    EmployeeRepository.getEmps()
        .then(emps =>{
            res.status(200).json(emps) ;

        })
        .catch(err=>{
            console.log(err);
        });
};

exports.getEmpById = (req, res, next) => {
    const empId = req.params.empId;
    EmployeeRepository.getEmpById(empId)
        .then(emp => {
            
            res.status(200).json(emp) ;
           
        });
}

exports.createEmp = (req, res, next) => {
    
    EmployeeRepository.createEmp(req.body)
        .then(newObj => {      
            res.status(201).json(newObj) ;
        })
        .catch(err => {

            if (!err.statusCode) {
                err.statusCode = 500;
            }
            next(err);
        });
}

exports.updateEmp = (req, res, next) => {
    const empId = req.params.empId;
    EmployeeRepository.updateEmp(empId, req.body)
        .then(result => {
            res.status(200).json({message: 'Pracownik updated', emp: result});
        })
        .catch(err => {
            if(!err.statusCode) {
                err.statusCode = 500;
            }
            next(err);
        });
};


exports.deleteEmp = (req, res, next) => {
    const empId = req.params.empId;
    EmployeeRepository.deleteEmp(empId)
        .then(result => {
            res.status(200).json({message: 'Pracownik deleted', emp: result});
        })
        .catch(err => {
            if(!err.statusCode) {
                err.statusCode = 500;
            }
            next(err);
        });
};