/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;



import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.nio.charset.Charset;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static java.nio.channels.SelectionKey.OP_WRITE;

public class ChatServer implements Runnable{
    String host;
    int port;
    ServerSocketChannel serverSocketChannel;
    Thread threadServer;
    Selector selector;

    String serverLog = "";
    String clientLog = "";
    Map<SocketChannel, String> mapOfID = new HashMap<>();;
    static final Charset ISO = Charset.forName("ISO-8859-2");


    public ChatServer(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public void startServer() {
        try {
            serverSocketChannel = ServerSocketChannel.open();
            serverSocketChannel.configureBlocking(false);
            serverSocketChannel.socket().bind(new InetSocketAddress(host, port));
            selector = Selector.open();
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
            threadServer = new Thread(this);
            threadServer.start();
            System.out.println("Server started\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void stopServer() {
        threadServer.interrupt();
        System.out.println("Server stopped");
    }

    public String getServerLog() {return serverLog;}

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                int count =  selector.select();
                if (count == 0)
                    continue;

                Iterator<SelectionKey> keys = selector.selectedKeys().iterator();


                while (keys.hasNext()) {
                    SelectionKey key = keys.next();
                    keys.remove();

                    if (key.isAcceptable()) {
                        SocketChannel socketChannel = serverSocketChannel.accept();
                        if (socketChannel != null)
                            socketChannel
                                    .configureBlocking(false)
                                    .register(selector, SelectionKey.OP_READ | OP_WRITE);
                        continue;
                    }

                    if (key.isReadable()) {
                        SocketChannel clientsSocket = (SocketChannel) key.channel();
                        ByteBuffer inByteBuffer = ByteBuffer.allocateDirect(1024);
                        String request;

                        clientsSocket.read(inByteBuffer);
                        inByteBuffer.flip();
                        request = ISO.decode(inByteBuffer).toString();

                        if (request.startsWith("login")) {
                            mapOfID.put(clientsSocket,   request.split(" ")[1]);
                            clientLog = mapOfID.get(clientsSocket) + " logged in\n";
                            serverLog += LocalTime.now().toString().substring(0,12) + " " + clientLog;
                            mapOfID.forEach((client, v) -> {
                                try {
                                    ByteBuffer byteBuffer = ByteBuffer.allocateDirect(clientLog.getBytes().length).put(ISO.encode(clientLog));
                                    byteBuffer.flip();
                                    client.write(byteBuffer);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            });
                        } else  if (request.startsWith("logout")){
                            clientLog = mapOfID.get(clientsSocket) + " logged out\n";
                            serverLog += LocalTime.now().toString().substring(0,12) + " " + clientLog;
                            mapOfID.forEach((client, v) -> {
                                try {
                                    ByteBuffer byteBuffer = ByteBuffer.allocateDirect(clientLog.getBytes().length).put(ISO.encode(clientLog));
                                    byteBuffer.flip();
                                    client.write(byteBuffer);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            });
                            mapOfID.remove(clientsSocket);

                        }else if(request.startsWith("ms")){
                            clientLog = mapOfID.get(clientsSocket) + ": " + request.split("ms")[1] + "\n";
                            serverLog += LocalTime.now().toString().substring(0,12) + " " + clientLog;
                            mapOfID.forEach((client, v) -> {
                                try {
                                    ByteBuffer byteBuffer = ByteBuffer.allocateDirect(clientLog.getBytes().length).put(ISO.encode(clientLog));
                                    byteBuffer.flip();
                                    client.write(byteBuffer);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            });
                        }
                    }
                }
            } catch (ClosedChannelException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}
