/**
 *
 *  @author Mykhalkiv Yaroslav S21339
 *
 */

package zad1;


import java.util.*;

public class Main {

  static List<String> getPricesInPLN(List<String> destinations, double xrate) {
    return ListCreator.collectFrom(destinations)
                       .when(  /*<-- lambda wyrażenie
                                *  selekcja wylotów z Warszawy (zaczynających się od WAW)
                                */
                               s -> {
                                   String str = (String) s;
                                   if (str.startsWith("WAW")) {
                                       return true;
                                   }else {
                                       return false;
                                   }
                               }

                        )
                       .mapEvery( /*<-- lambda wyrażenie
                                   *  wyliczenie ceny przelotu w PLN
                                   *  i stworzenie wynikowego napisu
                                   */
                               s -> {
                                   String str = (String)s;
                                   String[] tab = str.split("\\s");
                                   int x;
                                   x = Integer.parseInt(tab[tab.length - 1]);
                                   x *= xrate;
                                   tab[tab.length - 1] = String.valueOf(x);
                                   str = "to " +  tab[1] + " - price in PLN: " +  tab[tab.length - 1];
                                   return str;
                               }

                        );
  }

  public static void main(String[] args) {
    // Lista destynacji: port_wylotu port_przylotu cena_EUR 
    List<String> dest = Arrays.asList(
      "bleble bleble 2000",
      "WAW HAV 1200",
      "xxx yyy 789",
      "WAW DPS 2000",
      "WAW HKT 1000"
    );
    double ratePLNvsEUR = 4.30;
    List<String> result = getPricesInPLN(dest, ratePLNvsEUR);
    for (String r : result) System.out.println(r);
  }
}
