package zad2;

public class Main {
    public static void main(String[] args) {
        A a = new A(true,3);
        Klass kl = new Klass(44);
        System.out.println(a.getB() + " " + kl.getB());
    }
}
